library(dplyr)
library(ggplot2)
library(cowplot)
library(ggthemes)
library(Hmisc)
library(lazyeval)
library(ggrepel)
library(ggExtra)
library(tidyr)
library(coda)
library(ggthemes)


# load simulation output
load('logSummaries.RData')

covplot = function(ylab, par, stat, ref = .95) {
  # build plots that summarize simulation output
  #
  # Parameters:
  #  ylab - expression or label for y-axis
  #  par - parameter from "summaries" data frame to filter and plot
  #  stat - summary statistic to plot
  #  ref - value at which to plot a dotted reference line, NA to ignore

  mlabs = c('latent'='Unweighted', 'penalized.shape'='Penalized', 'wtd'='Weighted',
            'penalized.pc'='PC prior', 'wtd.updating'='Weighted (Upd.)')

  summaries$v = summaries[, stat]

  p = summaries %>%
    filter_(interp(~parameter==x, x=par)) %>%
    filter( model %in% c('latent', 'wtd', 'wtd.updating', 'penalized.pc')) %>%
    mutate(dep = factor(plyr::mapvalues(dep, levels(summaries$dep),
                                 capitalize(levels(summaries$dep))),
                        levels = c('Independent', 'Weak',
                                   'Moderate', 'Strong')),
           Model = factor(model, levels(summaries$model)[c(1,4,5,2,3,6)]),
           n.obs = paste('T=',n.obs,sep='')
           ) %>%
    # filter(dep != 'Independent') %>%
    group_by(dep, n.site, n.obs, Model) %>%
    summarise(v = mean(v)) %>%
    ggplot(aes(x = factor(n.site), y = v, shape = Model, color = Model)) +
    geom_point() +
    facet_grid(n.obs~dep) +
    xlab('Sites (N)') +
    scale_y_continuous(ylab) +
    scale_shape(solid = F, labels = mlabs) +
    scale_color_brewer(type = 'qual', palette = 'Dark2', labels = mlabs)  +
    theme_few() +
    theme(panel.border = element_blank(),
          axis.line.x = element_line(),
          axis.line.y = element_line())

  if(!is.na(ref)) { p + geom_hline(yintercept = ref, lty=3) }
  else { p }
}


# figure 1
covplot(ylab = '', par = 'rl', stat = 'coverage' ) +
  scale_y_continuous(expression(Q('.99|'~bold(eta)(bold(s)))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 2 
covplot(ylab = '', par = 'loc', stat = 'coverage' ) +
  scale_y_continuous(expression(mu(bold(s))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 
covplot(ylab = '', par = 'scale', stat = 'coverage' ) +
  scale_y_continuous(expression(sigma(bold(s))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 4
covplot(ylab = '', par = 'shape', stat = 'coverage' ) +
  scale_y_continuous(expression(xi(bold(s))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 5
covplot(ylab = expression(Q('.99|'~bold(eta)(bold(s)))~~'MSE'),
        par = 'rl', stat = 'mse', ref = NA )

# figure 6
covplot(ylab = expression(mu(bold(s))~~'MSE'),
        par = 'loc', stat = 'mse', ref = NA )

# figure 7
covplot(ylab = expression(sigma(bold(s))~~'MSE'),
        par = 'scale', stat = 'mse', ref = NA )

# figure 8
covplot(ylab = expression(xi(bold(s))~~'MSE'),
        par = 'shape', stat = 'mse', ref = NA )

# figure 9
covplot(ylab='y', par = 'rl', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(Q('.99|'~bold(eta)(bold(s)))~~'relative bias (%)'))

# figure 10
covplot(ylab='y', par = 'loc', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(mu(bold(s))~~'relative bias (%)'))

# figure 11
covplot(ylab='y', par = 'scale', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(sigma(bold(s))~~'relative bias (%)'))

# figure 12
covplot(ylab='y', par = 'shape', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(xi(bold(s))~~'relative bias (%)'))


#
# figure 13
#

# load fitted colorado models
load('penCompLogLink.RData')

rbind(characteristics %>% filter(n.site==50, n.obs==50) %>%
        mutate(Dependence =
                 plyr::mapvalues(dep, levels(characteristics$dep),
                                 capitalize(levels(characteristics$dep)))) %>%
        select(meanWts, Dependence),
      data.frame(meanWts = wts, Dependence = 'Observed (Colorado)')) %>%
  # order levels for plotting
  mutate(Dependence = factor(Dependence, levels(Dependence)[c(1,4,5,2,3)])) %>%
  # build basic density plot
  ggplot(aes(x = meanWts, linetype = Dependence, color = Dependence,
             size = Dependence, alpha = Dependence)) +
  geom_line(stat = "density") +
  # labels, ranges, margins
  xlab(expression(tilde(w)[bold(s)[j]])) +
  ylab('Density') +
  xlim(c(0.1,1)) +
  theme(plot.margin = unit(c(0.5,0,0,3),'cm')) +
  # line styles
  scale_color_manual(
    values = c('Strong' = '#1b9e77', 'Weak' = '#d95f02', 'Moderate' = '#7570b3',
               'Independent' = '#e7298a', 'Observed (Colorado)' = 'black')) +
  scale_linetype_manual(
    values = c('Strong' = 2, 'Moderate' = 4, 'Weak' = 5, 'Independent' = 3,
               'Observed (Colorado)' = 1) ) +
  scale_size_manual(
    values = c('Strong' = .5, 'Moderate' = .5, 'Weak' = .5, 'Independent' = .5,
               'Observed (Colorado)' = 1)) +
  scale_alpha_manual(
    values = c('Strong' = .8, 'Moderate' = .8, 'Weak' = .8, 'Independent' = .8,
               'Observed (Colorado)' = 1)) +
  # visually truncate density supports
  geom_hline(yintercept = 0, color = 'white', lwd = 1.5)


#
# figure 14
#

df = data.frame(x = colMeans(fit.rl),
                y = colMeans(fit.rl.wtd))  %>%
  mutate(label = ifelse(stn.info$city == 'Boulder', 'Boulder', NA))

boulder.ind = which(stn.info$city == 'Florissant')

p1 = df %>%
  ggplot(aes(x=x, y=y, label=label)) +
  geom_point(size = .8, data = df %>% filter(is.na(label))) +
  geom_point(data = df %>% filter(!is.na(label)), pch=4) +
  geom_abline(slope = 1, intercept = 0, lty = 3) +
  coord_equal() +
  scale_x_continuous(expression(hat(Q)('.99|'~bold(eta)(bold(s)))),
                     breaks = c(60, 80, mean(df$x), 100, 120),
                     labels = c(60, 80, expression(bar(Q)), 100, 120),
                     expand = c(.1,.1)) +
  scale_y_continuous(expression(hat(Q)[wtd]('.99|'~bold(eta)(bold(s)))),
                     breaks = c(60, 80, 100, 120),
                     labels = c(60, 80, 100, 120)) +
  theme_few() +
  theme(panel.border = element_blank(),
        axis.line.x = element_line(),
        axis.line.y = element_line()) +
  geom_vline(xintercept = mean(df$x), lty = 2, alpha = .3)

p1

