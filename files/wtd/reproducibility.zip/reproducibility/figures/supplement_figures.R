library(dplyr)
library(ggplot2)
library(cowplot)
library(ggthemes)
library(Hmisc)
library(lazyeval)
library(scales)
library(ggmap)
library(viridis)
library(ggrepel)
library(directlabels)
library(ggpubr)
library(stringr)
library(xtable)


load('penCompLogLink.RData')

dinvgamma = function(x, shape, scale, log = FALSE) {
  a = shape; b = scale
  res = a*log(b) - lgamma(a) -(a+1)*log(x) - b/x
  if(log) { res } else { exp(res) }
}

priorCompare = function(x, p, p.mean = NULL, plot.mean = TRUE,
                        xlab = NULL, ylab = NULL) {
  # for posterior samples of a single parameter, x, plot the prior and
  # posterior distributions for x
  #
  # Parameters:
  #  x - posterior samples for a single parameter
  #  p - vectorized prior distribution function for x
  #  p.mean - value of prior mean distribution; will be plotted if provided
  #  mean - TRUE to plot a vertical line at the posterior mean
  #  xlab - an x-axis label, if provided
  #  ylab - a y-axis label, if provided

  prior.col = 'salmon'

  # estimate posterior density
  d = density(x)

  # evaluate prior density over effective support of posterior density
  xseq = seq(from = min(d$x), to = max(d$x), length.out = 200)
  yseq = p(xseq)

  df = rbind(
    data.frame(x=d$x, y=d$y, Density='Posterior'),
    data.frame(x=xseq, y=yseq, Density='Prior')
  )

  p = ggplot(df, aes(x=x, y=y, col=Density)) +
    geom_line() +
    scale_color_brewer(type = 'qual', palette = 'Dark2') +
    theme(axis.title.y = element_text(angle=0))

  if(!is.null(p.mean)) { p = p + geom_vline(xintercept = p.mean, lty = 3,
                                            col = prior.col)}
  if(plot.mean) { p = p + geom_vline(xintercept = mean(x), lty = 3) }
  if(!is.null(xlab)) { p = p + xlab(xlab) }
  if(!is.null(ylab)) { p = p + ylab(ylab) }

  p
}

priorCovCompare = function(param) {
    print(ggarrange(

  # sill
  priorCompare(x = fit.wtd[[paste('chain', param, sep='.')]][,3],
               p = function(x) dinvgamma(x = x,
                                         shape = hyper$sills[[param]][1],
                                         scale = hyper$sills[[param]][2]),
               p.mean = hyper$sills[[param]][2] / (hyper$sills[[param]][1] - 1),
               xlab = expression(sigma[0]^2),
               ylab = expression(f(sigma[0]^2))),

  # range
  priorCompare(x = fit.wtd[[paste('chain', param, sep='.')]][,4],
               p = function(x) dgamma(x = x,
                                         shape = hyper$ranges[[param]][1],
                                         scale = hyper$ranges[[param]][2]),
               p.mean = hyper$ranges[[param]][2] * hyper$ranges[[param]][1],
               xlab = expression(lambda[0]),
               ylab = expression(f(lambda[0]))),

  # smoothness
  priorCompare(x = fit.wtd[[paste('chain', param, sep='.')]][,5],
               p = function(x) dgamma(x = x,
                                      shape = hyper$smooths[[param]][1],
                                      scale = hyper$smooths[[param]][2]),
               p.mean = hyper$smooths[[param]][2] * hyper$smooths[[param]][1],
               xlab = expression(nu[0]),
               ylab = expression(f(nu[0]))),

  nrow = 3,
  common.legend = TRUE,
  legend = 'right'

  ))
}


priorMeanCompare = function(param) {
    print(ggarrange(

  # intercept
  priorCompare(x = fit.wtd[[paste('chain', param, sep='.')]][,1],
               p = function(x) dnorm(x = x,
                                     mean = hyper$betaMeans[[param]][1],
                                     sd = sqrt(solve(hyper$betaIcov[[param]])[1,1])),
               p.mean = hyper$betaMeans[[param]][1],
               xlab = expression(beta[0]),
               ylab = expression(f(beta[0]))),

  # slope
  priorCompare(x = fit.wtd[[paste('chain', param, sep='.')]][,2],
               p = function(x) dnorm(x = x,
                                     mean = hyper$betaMeans[[param]][2],
                                     sd = sqrt(solve(hyper$betaIcov[[param]])[2,2])),
               p.mean = hyper$betaMeans[[param]][2],
               xlab = expression(beta[1]),
               ylab = expression(f(beta[1]))),
  nrow = 2,
  common.legend = TRUE,
  legend = 'right'

  ))
}


# figure 1
priorMeanCompare('loc')

# figure 2
priorCovCompare('loc')

# figure 3
priorMeanCompare('scale')

# figure 4
priorCovCompare('scale')

# figure 5
priorMeanCompare('shape')

# figure 6
priorCovCompare('shape')


#
# simulation summaries
#

load('logSummaries.RData')

covplot = function(ylab, par, stat, ref = .95) {
  # Parameters:
  #  ylab - expression or label for y-axis
  #  par - parameter from "summaries" data frame to filter and plot
  #  stat - summary statistic to plot
  #  ref - value at which to plot a dotted reference line, NA to ignore

  mlabs = c('latent'='Unweighted', 'penalized.shape'='Penalized', 'wtd'='Weighted',
            'penalized.pc'='PC prior', 'wtd.updating'='Weighted (Upd.)')

  summaries$v = summaries[, stat]

  p = summaries %>%
    filter_(interp(~parameter==x, x=par)) %>%
    filter( model %in% c('latent', 'wtd', 'wtd.updating', 'penalized.pc')) %>%
    mutate(dep = factor(plyr::mapvalues(dep, levels(summaries$dep),
                                 capitalize(levels(summaries$dep))),
                        levels = c('Independent', 'Weak',
                                   'Moderate', 'Strong')),
           Model = factor(model, levels(summaries$model)[c(1,4,5,2,3,6)]),
           n.obs = paste('T=',n.obs,sep='')
           ) %>%
    # filter(dep != 'Independent') %>%
    group_by(dep, n.site, n.obs, Model) %>%
    summarise(v = mean(v)) %>%
    ggplot(aes(x = factor(n.site), y = v, shape = Model, color = Model)) +
    geom_point() +
    facet_grid(n.obs~dep) +
    xlab('Sites (N)') +
    scale_y_continuous(ylab) +
    scale_shape(solid = F, labels = mlabs) +
    scale_color_brewer(type = 'qual', palette = 'Dark2', labels = mlabs)  +
    theme_few() +
    theme(panel.border = element_blank(),
          axis.line.x = element_line(),
          axis.line.y = element_line())

  if(!is.na(ref)) { p + geom_hline(yintercept = ref, lty=3) }
  else { p }
}


# figure 7
covplot(ylab = expression(Q('.99|'~bold(eta)(bold(s)))~~'MSE'),
        par = 'rl', stat = 'mse', ref = NA) +
  theme(text = element_text(size=16),
        axis.line = element_line())

# figure 8
covplot(ylab = '', par = 'rl', stat = 'coverage' ) +
  scale_y_continuous(expression(Q('.99|'~bold(eta)(bold(s)))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 9
covplot(ylab = '', par = 'loc', stat = 'coverage' ) +
  scale_y_continuous(expression(mu(bold(s))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 10
covplot(ylab = '', par = 'scale', stat = 'coverage' ) +
  scale_y_continuous(expression(sigma(bold(s))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 11
covplot(ylab = '', par = 'shape', stat = 'coverage' ) +
  scale_y_continuous(expression(xi(bold(s))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95))

# figure 12
covplot(ylab = expression(Q('.99|'~bold(eta)(bold(s)))~~'MSE'),
        par = 'rl', stat = 'mse', ref = NA )

# figure 13
covplot(ylab = expression(mu(bold(s))~~'MSE'),
        par = 'loc', stat = 'mse', ref = NA )

# figure 14
covplot(ylab = expression(sigma(bold(s))~~'MSE'),
        par = 'scale', stat = 'mse', ref = NA )

# figure 15
covplot(ylab = expression(xi(bold(s))~~'MSE'),
        par = 'shape', stat = 'mse', ref = NA )

# figure 16
covplot(ylab='y', par = 'rl', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(Q('.99|'~bold(eta)(bold(s)))~~'relative bias (%)'))

# figure 17
covplot(ylab='y', par = 'loc', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(mu(bold(s))~~'relative bias (%)'))

# figure 18
covplot(ylab='y', par = 'scale', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(sigma(bold(s))~~'relative bias (%)'))

# figure 19
covplot(ylab='y', par = 'shape', stat = 'bias.rel', ref = 0) +
  scale_y_continuous(expression(xi(bold(s))~~'relative bias (%)'))


#
# figure 20
#

load('penCompLogLink.RData')

# extract data for plotting (then plot it)
rbind(characteristics %>% filter(n.site==50, n.obs==50) %>%
        mutate(Dependence =
                 plyr::mapvalues(dep, levels(characteristics$dep),
                                 capitalize(levels(characteristics$dep)))) %>%
        select(meanWts, Dependence),
      data.frame(meanWts = wts, Dependence = 'Observed (Colorado)')) %>%
  # order levels for plotting
  mutate(Dependence = factor(Dependence, levels(Dependence)[c(1,4,5,2,3)])) %>%
  # build basic density plot
  ggplot(aes(x = meanWts, linetype = Dependence, color = Dependence,
             size = Dependence, alpha = Dependence)) +
  geom_line(stat = "density") +
  # labels, ranges, margins
  xlab(expression(tilde(w)[bold(s)[j]])) +
  ylab('Density') +
  xlim(c(0.1,1)) +
  theme(plot.margin = unit(c(0.5,0,0,3),'cm')) +
  # line styles
  scale_color_manual(
    values = c('Strong' = '#1b9e77', 'Weak' = '#d95f02', 'Moderate' = '#7570b3',
               'Independent' = '#e7298a', 'Observed (Colorado)' = 'black')) +
  scale_linetype_manual(
    values = c('Strong' = 2, 'Moderate' = 4, 'Weak' = 5, 'Independent' = 3,
               'Observed (Colorado)' = 1) ) +
  scale_size_manual(
    values = c('Strong' = .5, 'Moderate' = .5, 'Weak' = .5, 'Independent' = .5,
               'Observed (Colorado)' = 1)) +
  scale_alpha_manual(
    values = c('Strong' = .8, 'Moderate' = .8, 'Weak' = .8, 'Independent' = .8,
               'Observed (Colorado)' = 1)) +
  # visually truncate density supports
  geom_hline(yintercept = 0, color = 'white', lwd = 1.5)


#
# figure 21
#

df = data.frame(x = colMeans(fit.rl),
                y = colMeans(fit.rl.wtd))  %>%
  mutate(label = ifelse(stn.info$city == 'Boulder', 'Boulder', NA))

boulder.ind = which(stn.info$city == 'Florissant')

df %>%
  ggplot(aes(x=x, y=y, label=label)) +
  geom_point(size = .8, data = df %>% filter(is.na(label))) +
  geom_point(data = df %>% filter(!is.na(label)), pch=4) +
  geom_abline(slope = 1, intercept = 0, lty = 3) +
  coord_equal() +
  scale_x_continuous(expression(hat(Q)('.99|'~bold(eta)(bold(s)))),
                     breaks = c(60, 80, mean(df$x), 100, 120),
                     labels = c(60, 80, expression(bar(Q)), 100, 120),
                     expand = c(.1,.1)) +
  scale_y_continuous(expression(hat(Q)[wtd]('.99|'~bold(eta)(bold(s)))),
                     breaks = c(60, 80, 100, 120),
                     labels = c(60, 80, 100, 120)) +
  theme_few() +
  theme(panel.border = element_blank(),
        axis.line.x = element_line(),
        axis.line.y = element_line()) +
  geom_vline(xintercept = mean(df$x), lty = 2, alpha = .3)
