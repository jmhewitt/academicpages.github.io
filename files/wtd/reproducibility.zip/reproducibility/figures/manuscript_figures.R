library(dplyr)
library(ggplot2)
library(dplyr)
library(cowplot)
library(ggthemes)
library(Hmisc)
library(lazyeval)
library(scales)
library(ggmap)
library(viridis)
library(ggrepel)
library(directlabels)
library(ggpubr)
library(stringr)

# load simulation output
load('logSummaries.RData')

covplot = function(ylab, par, stat, ref = .95, ptsize = 1, lwdsize = 1) {
  # build plots that summarize simulation output
  #
  # Parameters:
  #  ylab - expression or label for y-axis
  #  par - parameter from "summaries" data frame to filter and plot
  #  stat - summary statistic to plot
  #  ref - value at which to plot a dotted reference line, NA to ignore
  #  ptsize - size of points in plot

  mlabs = c('latent'='Unweighted', 'penalized.shape'='Penalized', 'wtd'='Weighted',
            'penalized.pc'='PC prior', 'wtd.updating'='Weighted (Upd.)')

  summaries$v = summaries[, stat]

  p = summaries %>%
    filter_(interp(~parameter==x, x=par)) %>%
    filter( model %in% c('latent', 'wtd', 'wtd.updating', 'penalized.pc'),
           n.obs == 50) %>%
    mutate(dep = factor(plyr::mapvalues(dep, levels(summaries$dep),
                                 capitalize(levels(summaries$dep))),
                        levels = c('Independent', 'Weak',
                                   'Moderate', 'Strong')),
           Model = factor(model, levels(summaries$model)[c(1,4,5,2,3,6)])
           ) %>%
    group_by(dep, n.site, n.obs, Model) %>%
    summarise(v = mean(v)) %>%
    ggplot(aes(x = factor(n.site), y = v, shape = Model, color = Model)) +
    geom_point(size=ptsize, lwd=lwdsize) +
    facet_wrap(~dep, nrow=1) +
    xlab('Sites (N)') +
    scale_y_continuous(ylab) +
    scale_shape(solid = F, labels = mlabs) +
    scale_color_brewer(type = 'qual', palette = 'Dark2', labels = mlabs)  +
    theme_few() +
    theme(panel.border = element_blank(),
          axis.line.x = element_line(),
          axis.line.y = element_line())

  if(!is.na(ref)) { p + geom_hline(yintercept = c(.95), lty=3) }
  else { p }
}


# figure 1
covplot(ylab = '', par = 'rl', stat = 'coverage', ptsize=2.75, lwdsize = 2) +
  scale_y_continuous(expression(Q('.99|'~bold(eta)(bold(s)))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95)) +
  theme(text = element_text(size=16),
        axis.line = element_line())

# figure 2
covplot(ylab = expression(Q('.99|'~bold(eta)(bold(s)))~~'MSE'),
        par = 'rl', stat = 'mse', ref = NA, ptsize = 2.75, lwdsize = 2 ) +
  theme(text = element_text(size=16),
        axis.line = element_line())


# load fitted colorado models
load('penCompLogLink.RData')


# 
# latitude/longitude scales for spatial plots
#

lon_trans = function() {
  
  trans_new( name = 'lon', transform = function(x){x},
             inverse = function(x){x},
             format = function(x) {
               # map longitudes onto a 0-360 degree scale (1-179 E, 181-359 W)
               x = x %% 360
               # identify western longitudes
               W = x > 180
               # re-index western longitudes (accounts for NAs in x)
               W.ind = !is.na(W)
               x[W.ind][W[W.ind]] = - x[W.ind][W[W.ind]] %% 180
               # build labels
               lab = paste(as.character(x), ifelse(W, 'W', 'E'), sep='')
               # remove direction for 0 and 180 degrees
               lab = gsub('^(0E|0W)$', '0', lab)
               lab = gsub('^(180E|180W)$', '0', lab)
               # return labels
               lab
             } )
  
}

lat_trans = function() {
  
  trans_new( name = 'lat', transform = function(x){x},
             inverse = function(x){x},
             format = function(x) {
               S = x < 0
               gsub('^0N$', '0', paste(gsub('-', '', as.character(x)),
                                       ifelse(S, 'S', 'N'), sep=''))
             } )
  
}


#
# figure 3
#

st = map_data('county', region = 'Colorado')
county_col = 'gray90'

df = cbind(stn.info, wts, obs = colSums(!is.na(dat.wide)),
           dxi = (rl.wtd$est - rl$est)/rl$est)

ggplot(st, aes(x=long, y=lat, group=group)) +
  # plot counties
  geom_polygon(fill=NA, color=county_col, lty=3) +
  # plot weights
  geom_point(data = cbind(coord, data.frame(wts=wts)),
             mapping=aes(x=Lon, y=Lat, color=wts), inherit.aes = F) +
  scale_color_viridis(expression(italic(w)[bold(s)[j]]), direction = -1) +
  # label stations
  geom_point(aes(x=Lon, y=Lat, label=city),
                  data = df %>%
                    filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                       'Denver', 'Colorado Springs')) %>%
                                       group_by(city) %>%
                    slice(1),
                  color='black', inherit.aes = F, pch = 1) +
  geom_text_repel(aes(x=Lon, y=Lat, label=city),
                  data = df %>%
                    filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                       'Denver', 'Colorado Springs'))
                                       %>% group_by(city) %>%
                    slice(1),
                  color='#333333', inherit.aes = F, fontface='bold') +
  # modify x and y axes
  scale_x_continuous('', trans = lon_trans(), limits = range(coord$Lon)+.03,
                     oob = function(x, range=c(0,1), only.finite=T){x}) +
  scale_y_continuous('', trans = lat_trans(), limits = range(coord$Lat)+.1,
                     oob = function(x, range=c(0,1), only.finite=T){x}) +
  # clean up plot settings
  theme_few() +
  theme(panel.border = element_blank(),
        text = element_text(size=12),
        plot.margin = unit(c(0,0,0,0), 'mm'),
        title = element_text(size=12),
        axis.text = element_text(size=12),
        plot.title = element_text(family = 'sans', size = 16)) +
  coord_equal()


#
# figure 4
#

# load kriged return levels
load('penCompLogLinkKrigFull.RData')

coord.pred = fit.wtd.krig$coord

st = map_data('county', region = 'Colorado')
county_col = 'darkgrey'

df = cbind(stn.info, wts, obs = colSums(!is.na(dat.wide)),
           dxi = (rl.wtd$est - rl$est)/rl$est)

pl = function(krig, mm = T, contour.break = (1:6) * ifelse(mm, 25.4, 1),
              limits.fill = NA, param = 'rl', FUN=mean, log=F,
              categorical = F) {
  # Make nice contour plots of kriged surfaces of return level and parameter
  # estimates
  #
  # Parameters:
  #  krig - kriging output
  #  mm - TRUE to make plot units mm, FALSE for inches
  #  param - name of paramter to plot, e.g., 'rl', 'shapes', 'scales', 'locs'
  #  log - TRUE to plot the response on the log scale
  # categorical - TRUE to plot the data as categorical rather than continuous

  # extract kriged surface
  df.krig = data.frame(krig$coord,
                       rl.est = apply(krig[[param]], 2, FUN,
                                      na.rm=TRUE) * ifelse(mm, 1, .039))
  if(log){
    df.krig[,3] = log(df.krig[,3])
  }

  bincol <- function(x,low,medium,high) {

    colfunc <- colorRampPalette(c(low, medium, high))

    binned <- cut(x,contour.break, include.lowest = TRUE)

    res <- colfunc(length(unique(binned)))[as.integer(binned)]
    labs <- names(res)
    names(res) <- as.character(binned)
    list(val = as.numeric(binned),
         cols = res,
         labels = labs)
  }

  # color range and labels
  if(any(is.na(limits.fill))) {
    limits.fill = range(df.krig$rl.est)
  }
  if(param=='rl') {
    fill.lab = bquote(hat(Q)('.99|'~bold(Y))~~
                        .(ifelse(mm,'(mm)','(in.)')))
  } else {
    fill.lab = param
  }

  # contour settings
  contour.col = 'black'

  if(categorical) {
    cat = bincol(df.krig[,3], 'blue', 'yellow', 'red')
    labels <- unique(names(cat$cols))
    breaks <- unique(cat$cols)
    breaks <- breaks[order(labels,decreasing = TRUE)]
    labels = labels[order(labels)]
    labels = labels[order(as.numeric(str_match(labels, "(?:\\()([0-9]+)")[,2]))]

    df.krig$rl.cat = cat$val
    df.krig = df.krig[complete.cases(df.krig),]

    raster.aes = aes(x=Lon, y=Lat, fill=rl.cat)
    limits.fill = range(df.krig$rl.cat)
    df.krig$rl.cat = factor(df.krig$rl.cat)
    color_scale = scale_fill_viridis_d(fill.lab, labels = labels, direction = -1)
  } else {
    raster.aes = aes(x=Lon, y=Lat, fill=rl.est)
    color_scale = scale_fill_distiller(fill.lab, type = 'seq',
                                       palette = 'YlOrBr',
                                       limits = limits.fill, direction = 1)
  }

  # build and return plot
  ggplot(st, aes(x=long, y=lat, group=group)) +
    # plot and color kriged RL surface
    geom_raster(raster.aes, data = df.krig,inherit.aes = F, alpha=.9) +
    color_scale +
    # plot counties
    geom_polygon(fill=NA, color=county_col, lty=3) +
    # plot station locations
    geom_point(data = cbind(coord, data.frame(wts=wts)),
               mapping=aes(x=Lon, y=Lat), inherit.aes = F, pch = 21) +
    # label stations
    geom_point(data = df %>%
                 filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                    'Denver', 'Colorado Springs'))
                                    %>% group_by(city) %>%
                 slice(1),
               mapping=aes(x=Lon, y=Lat), inherit.aes = F, color='white') +
    geom_text_repel(aes(x=Lon, y=Lat, label=city),
                    data = df %>%
                      filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                         'Denver', 'Colorado Springs'))
                                         %>% group_by(city) %>%
                      slice(1),
                    color='white', inherit.aes = F, fontface='bold') +
    # modify x and y axes
    scale_x_continuous('', trans = lon_trans(), limits = range(coord$Lon)+.03,
                       oob = function(x, range=c(0,1), only.finite=T){x}) +
    scale_y_continuous('', trans = lat_trans(), limits = range(coord$Lat)+.1,
                       oob = function(x, range=c(0,1), only.finite=T){x}) +
    # clean up plot settings
    theme_few() +
    theme(panel.border = element_blank(),
        plot.margin = unit(c(0,4,-4,6), 'mm'),
        title = element_text(size=12),
        axis.text = element_text(size=12),
        plot.title = element_text(family = "sans",
                                  size = 16,
                                  margin=margin(0,0,-10,0))) +
    coord_equal()
}

bks = c(seq(from = 25, to = 200, by = 25), 455)

ggarrange(
  pl(fit.krig, contour.break = bks, categorical = T,
     mm=T),
  pl(fit.wtd.krig, contour.break = bks, categorical = T,
     mm=T),
  ncol=2, common.legend = T, legend = 'bottom', labels = c('A)','B)')
)

