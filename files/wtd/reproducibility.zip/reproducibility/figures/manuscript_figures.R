library(dplyr)
library(ggplot2)
library(cowplot)
library(ggthemes)
library(Hmisc)
library(lazyeval)
library(scales)
library(ggmap)
library(viridis)
library(ggrepel)
library(directlabels)
library(ggpubr)
library(stringr)
library(xtable)

# support for table plotting
printbold = function(x, which = NULL, each = c("column", "row"), inds=NULL, max = TRUE,
             NA.string = "", type = c("latex", "html"),
             sanitize.text.function = function(x){x},
             sanitize.rownames.function = function(x){x},
             sanitize.colnames.function = function(x){x},
             include.rownames = F, reformat = T, ...) {
    stopifnot(inherits(x, "xtable"))
    each <- match.arg(each)
    type <- match.arg(type)
    digits <- rep(digits(x), length = ncol(x)+1)
    if (!is.null(which)) {
        stopifnot(nrow(which) == nrow(x))
        stopifnot(ncol(which) == ncol(x))
        boldmatrix <- which
    } else {
        boldmatrix <- matrix(FALSE, ncol = ncol(x), nrow = nrow(x))
        ## round values before calculating max/min to avoid trivial diffs
        for (i in 1:ncol(x)) {
            if (!is.numeric(x[,i])) next
            x[,i] <- round(x[,i], digits = digits[i+1])
        }
        if (each == "column") {
            max <- rep(max, length = ncol(x))
            for (i in 1:ncol(x)) {
                xi <- x[inds,i]
                if (!is.numeric(xi)) next
                if (is.na(max[i])) next
                imax <- max(xi, na.rm = TRUE)
                if (!max[i])
                    imax <- min(xi, na.rm = TRUE)
                boldmatrix[xi == imax, i] <- TRUE
            }
        } else if (each == "row") {
            max <- rep(max, length = nrow(x))
            for (i in 1:nrow(x)) {
                xi <- x[i,inds]
                ok <- sapply(xi, is.numeric)
                if (!any(ok)) next
                if (is.na(max[i])) next
                imax <- max(unlist(xi[ok]), na.rm = TRUE)
                if (!max[i])
                    imax <- min(unlist(xi[ok]), na.rm = TRUE)
                whichmax <- sapply(xi, identical, imax)
                boldmatrix[i, inds[whichmax]] <- TRUE
            }
        }
    }
    ## need to convert to character
    ## only support per-column formats, not cell formats
    display <- rep(display(x), length = ncol(x)+1)
    for (i in 1:ncol(x)) {
        # if (!is.numeric(x[,i])) next # don't bold highlight text columns/rows
        ina <- is.na(x[,i])
        for(j in 1:nrow(x)) {
          # if(is.numeric(x[j,i])) {
            if(reformat) {
              x[j,i] <- formatC(x[j,i], digits = digits[i+1],
                             format = display[i+1])
            }
          # }
        }
        x[ina, i] <- NA.string
        display(x)[i+1] <- "s"
        ## embolden
        yes <- boldmatrix[,i]
        if (type == "latex") {
            x[yes,i] <- paste("\\textbf{", x[yes,i], "}", sep = "")
        } else {
            x[yes,i] <- paste("<strong>", x[yes,i], "</strong>", sep = "")
        }
    }
    print(x, ..., type = type, NA.string = NA.string,
          sanitize.text.function = sanitize.text.function,
          sanitize.rownames.function = sanitize.rownames.function,
          sanitize.colnames.function = sanitize.colnames.function,
          caption.placement = 'top',
          include.rownames = include.rownames, comment = F, timestamp = F,
          booktabs = T)
}


load('logSummaries.RData')


covplot = function(ylab, par, stat, ref = .95, ptsize = 1, lwdsize = 1) {
  # Parameters:
  #  ylab - expression or label for y-axis
  #  par - parameter from "summaries" data frame to filter and plot
  #  stat - summary statistic to plot
  #  ref - value at which to plot a dotted reference line, NA to ignore
  #  ptsize - size of points in plot

  mlabs = c('latent'='Unweighted', 'penalized.shape'='Penalized', 'wtd'='Weighted',
            'penalized.pc'='PC prior', 'wtd.updating'='Weighted (Upd.)')

  summaries$v = summaries[, stat]

  p = summaries %>%
    filter_(interp(~parameter==x, x=par)) %>%
    filter( model %in% c('latent', 'wtd', 'wtd.updating', 'penalized.pc'),
           n.obs == 50) %>%
    mutate(dep = factor(plyr::mapvalues(dep, levels(summaries$dep),
                                 capitalize(levels(summaries$dep))),
                        levels = c('Independent', 'Weak',
                                   'Moderate', 'Strong')),
           Model = factor(model, levels(summaries$model)[c(1,4,5,2,3,6)])
           ) %>%
    # filter(dep != 'Independent') %>%
    group_by(dep, n.site, n.obs, Model) %>%
    summarise(v = mean(v)) %>%
    ggplot(aes(x = factor(n.site), y = v, shape = Model, color = Model)) +
    geom_point(size=ptsize, lwd=lwdsize) +
    facet_wrap(~dep, nrow=1) +
    xlab('Sites (N)') +
    scale_y_continuous(ylab) +
    scale_shape(solid = F, labels = mlabs) +
    scale_color_brewer(type = 'qual', palette = 'Dark2', labels = mlabs)  +
    theme_few() +
    theme(panel.border = element_blank(),
          axis.line.x = element_line(),
          axis.line.y = element_line())

  if(!is.na(ref)) { p + geom_hline(yintercept = c(.95), lty=3) }
  else { p }
}


# figure 1
covplot(ylab = '', par = 'rl', stat = 'coverage', ptsize=2.75, lwdsize = 2) +
  scale_y_continuous(expression(Q('.99|'~bold(eta)(bold(s)))~~'Coverage'),
                       breaks = c(.7, .8, .9, .95),
                       labels = c(.7, .8, .9, .95)) +
  theme(text = element_text(size=16),
        axis.line = element_line())


# load application data
load('penCompLogLink.RData')

# get indices for holdout set
test.cities = c('Greeley', 'Longmont', 'Nederland', 'Aurora', 'Parker',
                'Pueblo', 'Penrose')
test.inds = stn.info$city %in% test.cities


lon_trans = function() {

  trans_new( name = 'lon', transform = function(x){x},
             inverse = function(x){x},
             format = function(x) {
               # map longitudes onto a 0-360 degree scale (1-179 E, 181-359 W)
               x = x %% 360
               # identify western longitudes
               W = x > 180
               # re-index western longitudes (accounts for NAs in x)
               W.ind = !is.na(W)
               x[W.ind][W[W.ind]] = - x[W.ind][W[W.ind]] %% 180
               # build labels
               lab = paste(as.character(x), ifelse(W, 'W', 'E'), sep='')
               # remove direction for 0 and 180 degrees
               lab = gsub('^(0E|0W)$', '0', lab)
               lab = gsub('^(180E|180W)$', '0', lab)
               # return labels
               lab
             } )

}

lat_trans = function() {

  trans_new( name = 'lat', transform = function(x){x},
             inverse = function(x){x},
             format = function(x) {
               S = x < 0
               gsub('^0N$', '0', paste(gsub('-', '', as.character(x)),
                                       ifelse(S, 'S', 'N'), sep=''))
             } )

}


#
# figure 2
#

st = map_data('county', region = 'Colorado')
county_col = 'gray90'

df = cbind(stn.info, wts, obs = colSums(!is.na(dat.wide)),
           dxi = (rl.wtd$est - rl$est)/rl$est)

# create holdout set
test.cities = c('Greeley', 'Longmont', 'Nederland', 'Aurora', 'Parker',
                'Pueblo', 'Penrose')
test.inds = stn.info$city %in% test.cities

# build and return plot
ggplot(st, aes(x=long, y=lat, group=group)) +
  # plot counties
  geom_polygon(fill=NA, color=county_col, lty=3) +
  # plot weights
  geom_point(data = cbind(coord, data.frame(wts=wts)),
             mapping=aes(x=Lon, y=Lat, color=wts), inherit.aes = F) +
  scale_color_viridis(expression(italic(w)[bold(s)[j]]), direction = -1) +
  # highlight holdout cities
  geom_point(data = cbind(coord, data.frame(wts=wts))[test.inds,],
             mapping=aes(x=Lon, y=Lat, color=wts), inherit.aes = F, pch = 5,
             color = 'black', size = 4, alpha = .6, stroke = 1.125) +
  # label stations
  geom_point(aes(x=Lon, y=Lat, label=city),
                  data = df %>%
                    filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                       'Denver', 'Colorado Springs')) %>%
                                       group_by(city) %>%
                    slice(1),
                  color='black', inherit.aes = F, pch = 1) +
  geom_text_repel(aes(x=Lon, y=Lat, label=city),
                  data = df %>%
                    filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                       'Denver', 'Colorado Springs'))
                                       %>% group_by(city) %>%
                    slice(1),
                  color='#333333', inherit.aes = F, fontface='bold') +
  # modify x and y axes
  scale_x_continuous('', trans = lon_trans(), limits = range(coord$Lon)+.03,
                     oob = function(x, range=c(0,1), only.finite=T){x}) +
  scale_y_continuous('', trans = lat_trans(), limits = range(coord$Lat)+.1,
                     oob = function(x, range=c(0,1), only.finite=T){x}) +
  # clean up plot settings
  theme_few() +
  theme(panel.border = element_blank(),
        text = element_text(size=12),
        plot.margin = unit(c(0,0,0,0), 'mm'),
        title = element_text(size=12),
        axis.text = element_text(size=12),
        plot.title = element_text(family = 'sans', size = 16)) +
  coord_equal()


#
# figure 3
#

load('penCompLogLinkKrigFull.RData')

coord.pred = fit.wtd.krig$coord

unloadNamespace('SpatialExtremes')

st = map_data('county', region = 'Colorado')
county_col = 'darkgrey'

df = cbind(stn.info, wts, obs = colSums(!is.na(dat.wide)),
           drl = (rl.wtd$est - rl$est)/rl$est)

pl = function(krig, mm = T, contour.break = (1:6) * ifelse(mm, 25.4, 1),
              limits.fill = NA, param = 'rl', FUN=mean, log=F,
              categorical = F) {
  # Make nice contour plots of kriged surfaces of return level and parameter
  # estimates
  #
  # Parameters:
  #  krig - kriging output
  #  mm - TRUE to make plot units mm, FALSE for inches
  #  param - name of paramter to plot, e.g., 'rl', 'shapes', 'scales', 'locs'
  #  log - TRUE to plot the response on the log scale
  # categorical - TRUE to plot the data as categorical rather than continuous

  # extract kriged surface
  df.krig = data.frame(krig$coord,
                       rl.est = apply(krig[[param]], 2, FUN,
                                      na.rm=TRUE) * ifelse(mm, 1, .039))
  if(log){
    df.krig[,3] = log(df.krig[,3])
  }

  bincol <- function(x,low,medium,high) {

    colfunc <- colorRampPalette(c(low, medium, high))

    binned <- cut(x,contour.break, include.lowest = TRUE)

    res <- colfunc(length(unique(binned)))[as.integer(binned)]
    labs <- names(res)
    names(res) <- as.character(binned)
    list(val = as.numeric(binned),
         cols = res,
         labels = labs)
  }

  # color range and labels
  if(any(is.na(limits.fill))) {
    limits.fill = range(df.krig$rl.est)
  }
  if(param=='rl') {
    fill.lab = bquote(hat(Q)('.99|'~bold(Y))~~
                        .(ifelse(mm,'(mm)','(in.)')))
  } else {
    fill.lab = param
  }

  # contour settings
  contour.col = 'black'

  if(categorical) {
    cat = bincol(df.krig[,3], 'blue', 'yellow', 'red')
    labels <- unique(names(cat$cols))
    breaks <- unique(cat$cols)
    breaks <- breaks[order(labels,decreasing = TRUE)]
    labels = labels[order(labels)]
    labels = labels[order(as.numeric(str_match(labels, "(?:\\()([0-9]+)")[,2]))]

    df.krig$rl.cat = cat$val
    df.krig = df.krig[complete.cases(df.krig),]

    raster.aes = aes(x=Lon, y=Lat, fill=rl.cat)
    limits.fill = range(df.krig$rl.cat)
    df.krig$rl.cat = factor(df.krig$rl.cat)
    # color_scale = scale_fill_brewer(fill.lab, type = 'seq',
    #                                 palette = 'PuRd', labels = labels)
    color_scale = scale_fill_viridis_d(fill.lab, labels = labels, direction = -1)
  } else {
    raster.aes = aes(x=Lon, y=Lat, fill=rl.est)
    color_scale = scale_fill_distiller(fill.lab, type = 'seq',
                                       palette = 'YlOrBr',
                                       limits = limits.fill, direction = 1)
  }

  # build and return plot
  ggplot(st, aes(x=long, y=lat, group=group)) +
    # plot and color kriged RL surface
    geom_raster(raster.aes, data = df.krig,inherit.aes = F, alpha=.9) +
    color_scale +
    # add contours
    # geom_contour(aes(x=Lon, y=Lat, z=rl.est), data = df.krig,
    #              inherit.aes = F, breaks = contour.break,
    #              stat='contour', color=contour.col) +
    # plot counties
    geom_polygon(fill=NA, color=county_col, lty=3) +
    # plot station locations
    geom_point(data = cbind(coord, data.frame(wts=wts)),
               mapping=aes(x=Lon, y=Lat), inherit.aes = F, pch = 21) +
    # highlight holdout cities
    geom_point(data = cbind(coord, data.frame(wts=wts))[test.inds,],
               mapping=aes(x=Lon, y=Lat, color=wts), inherit.aes = F, pch = 5,
               color = 'white', size = 4, alpha = .85, stroke = 1.125) +
    # label stations
    geom_point(data = df %>%
                 filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                    'Denver', 'Colorado Springs'))
                                    %>% group_by(city) %>%
                 slice(1),
               mapping=aes(x=Lon, y=Lat), inherit.aes = F, color='white') +
    geom_text_repel(aes(x=Lon, y=Lat, label=city),
                    data = df %>%
                      filter(city %in% c('Fort Collins', 'Greeley', 'Boulder',
                                         'Denver', 'Colorado Springs'))
                                         %>% group_by(city) %>%
                      slice(1),
                    color='white', inherit.aes = F, fontface='bold') +
    # modify x and y axes
    scale_x_continuous('', trans = lon_trans(), limits = range(coord$Lon)+.03,
                       oob = function(x, range=c(0,1), only.finite=T){x}) +
    scale_y_continuous('', trans = lat_trans(), limits = range(coord$Lat)+.1,
                       oob = function(x, range=c(0,1), only.finite=T){x}) +
    # clean up plot settings
    theme_few() +
    theme(panel.border = element_blank(),
        plot.margin = unit(c(0,4,-4,6), 'mm'),
        title = element_text(size=12),
        axis.text = element_text(size=12),
        plot.title = element_text(family = "sans",
                                  size = 16,
                                  margin=margin(0,0,-10,0))) +
    coord_equal()
}

bks = c(seq(from = 25, to = 200, by = 25), 455)

ggarrange(
  pl(fit.krig, contour.break = bks, categorical = T,
     mm=T),
  pl(fit.wtd.krig, contour.break = bks, categorical = T,
     mm=T),
  ncol=2, common.legend = T, legend = 'bottom', labels = c('A)','B)')
)


rm(fit.krig, fit.wtd.krig)


#
# table 3
#

# load holdout results
load('co_loo.RData')

# assemble base table of posterior log scores
df = data.frame(
  city = test.cities,
  WTD = apply(fit.wtd.krig$ll, 2, function(x) { mean(x[is.finite(x)])}),
  UNWTD = apply(fit.krig$ll, 2, function(x) { mean(x[is.finite(x)])})
)

#
# reformat table for display
#

df2 = stn.info[test.inds,] %>%
  left_join(df) %>%
  arrange(-Lat) %>%
  mutate(City = city,
         Lat = round(Lat, 1),
         Lon =  round(- (Lon %% 360) %% 180, 1),
         WTD = round(WTD, 0),
         UNWTD = round(UNWTD, 0)) %>%
  select(Lat, Lon, City, WTD, UNWTD)

# bold the models that have higher log score
bolds = matrix(FALSE, nrow = nrow(df2), ncol = ncol(df2))
for(i in 1:nrow(bolds)){
  if(df2$WTD[i] > df2$UNWTD[i]) {
    bolds[i,4] = TRUE
  } else {
    bolds[i,5] = TRUE
  }
}

# force formatting on scores
df2 = df2 %>% mutate(
  Lat = sprintf('%.1f', Lat),
  WTD = gsub('-', '$-$', formatC(WTD, format = 'd', big.mark = ',')),
  UNWTD = gsub('-', '$-$', formatC(UNWTD, format = 'd', big.mark = ','))
)

# update column labels
colnames(df2)[1:2] = c('Lat.', 'Lon.')
colnames(df2)[4:5] = c('$\\ell_{wtd}\\paren{\\vs_0}$','$\\ell\\paren{\\vs_0}$')

# print table
printbold(xtable(df2, label = 'table:co_holdout_table', caption = 'Comparison of log-scores for the weighted $\\ell_{wtd}\\paren{\\vs_0}$ and unweighted models $\\ell\\paren{\\vs_0}$ at holdout cities; the highest log-score is highlighted for each city.  The weighted likelihood model tends to have higher log-scores at holdout cities, suggesting better out-of-sample predictive performance in the targeted regions.  The low log-scores in the bottom row also suggest neither model is predictive of extreme precipitation in Pueblo.', digits = 1,
                 align = c('l', 'l', 'r', 'l', 'r', 'r')), which = bolds)
