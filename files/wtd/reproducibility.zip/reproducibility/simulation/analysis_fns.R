# initial simulation and fitting of spatial extremes models
library(SpatialExtremes)
# mcmc posterior analysis
library(coda)
# data manipulation
library(dplyr)
library(reshape2)
# convenient looping
library(foreach)
# multivariate normal likelihoods
library(mvtnorm)
# for quadrature rules
library(gaussquad)


rBR <- function(n, coord, lambda, alpha, partition = FALSE) {
  # simulation (exact) of Brown-Resnick processes

  coord <- scale(coord, scale = FALSE)

  # semi-variogram
  gammah <- function(h, par){
    nug <- par[1]
    lambda <- par[2]
    alpha <- par[3]
    return(nug+(sqrt(sum(h^2))/lambda)^alpha)
  }

  d <- nrow(coord)
  D <- as.matrix(dist(coord))
  S0 <- matrix(rep(apply(coord,1,gammah,c(0,lambda,alpha)),d),ncol=d)
  S <- S0+t(S0)-(D/lambda)^alpha
  A <- t(chol(S))

  shiftSdiag <- function(k) {
    coord2 <- coord - matrix(rep(coord[k, ], d), ncol = 2, byrow = TRUE)
    return(apply(coord2,1,gammah,c(0,lambda,alpha)))
  }

  SS <- matrix(ncol = d, nrow = d)
  for (l in 1:d) {
    SS[l, ] <- shiftSdiag(l)
  }

  MZ <- matrix(ncol = d, nrow = n)
  Mpart <- matrix(ncol = d, nrow = n)

  N <- 1000

  b <- d

  for (k in 1:n) {

    P <- matrix(nrow = 0, ncol = d)
    Q <- rep(0, N)
    Z <- rep(0, d)
    Ind <- rep(0, d)

    end <- FALSE
    i <- 0

    while (!end) {
      i <- i + 1
      V <- matrix(rnorm(N * d), ncol = N)
      indSS <- sample(1:d,N,replace=TRUE)
      W1 <- A%*%V-t(SS[indSS,])
      W <- exp(log(d)+W1-matrix(rep(log(apply(exp(W1),2,sum)),d),nrow=d,byrow=TRUE))

      Q <- Q[N] + cumsum(rexp(N, 1))
      P <- t(W)/Q

      max.ind <- apply(P, 2, which.max)+rep(max(Ind),d)
      maxP <- apply(P, 2, max)
      Ind[maxP>Z] <- max.ind[maxP>Z] #indice of max (only for the new components in maxP)
      Z <- apply(rbind(maxP, Z), 2, max) #the max

      end <- all(Z > b/Q[N])
    }
    MZ[k,] <- Z
    Indf <- as.factor(Ind)
    levels(Indf) <- c(1:nlevels(Indf))
    Mpart[k,] <- as.numeric(Indf)
  }
  if (partition==FALSE){return(MZ)}
  else {
    return(list(Z=MZ,partition=Mpart))
  }
}

GEV.CO.moderate = list(
  loc = list(sill = 4, range = 20, smooth = 1),
  scale = list(sill = .15, range = 5, smooth = 1),
  shape = list(sill = .0012, range = 10, smooth = 1, mean = .12)
)


sim = function(rl, n.site, n.obs, BR, lambda, alpha, gev.priors, mods=NULL) {
  # Parameters:
  #   rl - X year return level (rec: 100)
  #   n.site - number of sites to simulate (rec: 30)
  #   n.obs - number of observations to simulate from each site (rec: 50)
  #   BR - T/F to simulate data from Brown-Resnick process vs. latent spatial
  #        extremes process (rec: F)
  #   lambda - parameter for BR range (rec: .5)
  #   alpha - parameter for BR shape (rec: .5)
  #   gev.priors - list of GP parameters used to simulate the latent GEV
  #     parameters (rec: GEV.CO)
  #   mods - character vector of models for which to run analysis.  will run
  #     all models by default if mods=NULL


  # initialize return object, which will contain key simulation params
  res = list()
  res$params = as.list(sys.call())
  res$params = lapply(res$params, function(x){
    ifelse(is.symbol(x), as.name(x), eval(x))
  })


  #
  # simulate data
  #

  # Random spatial configuration of sites
  lon <- runif(n.site, -10, 10)
  lat <- runif(n.site, -10 , 10)
  coord <- cbind(lon, lat)

  res$coord = coord

  gp.loc <- rgp(1, coord, "powexp",
                sill = gev.priors$loc$sill,
                range = gev.priors$loc$range,
                smooth = gev.priors$loc$smooth)
  gp.scale <- rgp(1, coord, "powexp",
                  sill = gev.priors$scale$sill,
                  range = gev.priors$scale$range,
                  smooth = gev.priors$scale$smooth)
  gp.shape <- rgp(1, coord, "powexp",
                  sill = gev.priors$shape$sill,
                  range = gev.priors$shape$range,
                  smooth = gev.priors$shape$smooth)

  locs <- 26 + 0.5 * coord[,"lon"] + gp.loc
  scales <- exp(log(8) + .05 * coord[,"lat"] + gp.scale)
  shapes <- gev.priors$shape$mean + gp.shape

  # try to ensure we simulate data with non-negative shape parameters
  maxTries = 1e3
  j = 0
  while(any(shapes<0,shapes>1)) {

    gp.shape <- rgp(1, coord, "powexp",
                    sill = gev.priors$shape$sill,
                    range = gev.priors$shape$range,
                    smooth = gev.priors$shape$smooth)
    shapes <- gev.priors$shape$mean + gp.shape

    # break loop
    j = j + 1
    if(j>maxTries) {
      break
    }
  }

  res$locs = as.numeric(locs)
  res$scales = as.numeric(scales)
  res$shapes = as.numeric(shapes)

  # theoretical return levels
  rl.p = 1-1/rl
  theoretical.rl = sapply(1:n.site, function(i) {
    qgev(rl.p, locs[1,i], scales[1,i], shapes[1,i])
  })

  res$rls = as.numeric(theoretical.rl)

  # simulate data
  data <- matrix(NA, n.obs, n.site)
  if(BR) {
    # simulate from Brown Resnick model
    data = rBR(n.obs, coord, lambda = lambda, alpha = alpha)
    for (i in 1:n.site)
      data[,i] = locs[i] + scales[i] / shapes[i] * (data[,i]^shapes[i] -1)
  } else {
    # simulate from latent spatial extemes model
    for (i in 1:n.site)
      data[,i] = rgev(n.obs, locs[i], scales[i], shapes[i])
  }

  res$data = data


  #
  # latent model settings and initialization
  #

  loc.form <- y ~ lon
  scale.form <- y ~ lat
  shape.form <- y ~ 1

  hyper <- list()
  # weakly informative prior; infinite mean and variance, mean at truth
  hyper$sills <- list(loc = c(2,gev.priors$loc$sill), 
                      scale = c(2,gev.priors$scale$sill), 
                      shape = c(2,gev.priors$shape$sill))
  # weakly informative prior; large coefficient of variation (i.e., variance), 
  #                           mode at truth
  hyper$ranges <- list(loc = c(2, gev.priors$loc$range), 
                       scale = c(2, gev.priors$scale$range),
                       shape = c(2, gev.priors$shape$range))
  # weakly informative, but greater mass toward zero; mode at truth
  hyper$smooths <- list(loc = c(2, gev.priors$loc$smooth), 
                        scale = c(2, gev.priors$scale$smooth),
                        shape = c(2, gev.priors$shape$smooth))
  # uninformative prior means for beta
  hyper$betaMeans <- list(loc = rep(0, 2), scale = c(0, 0), shape = 0)
  # vague prior cov. for means
  hyper$betaIcov <- list(loc = solve(diag(c(400, 100))),
                         scale = solve(diag(c(400, 100))),
                         shape = solve(diag(c(100), 1, 1)))

  prop <- list(gev = c(1.2, 0.08, 0.08),
               ranges = c(0.7, 0.8, 0.7),
               smooths = c(0,0,0))

  start <- list(sills = c(gev.priors$loc$sill,
                          gev.priors$scale$sill,
                          gev.priors$shape$sill),
                ranges = c(gev.priors$loc$range,
                           gev.priors$scale$range,
                           gev.priors$shape$range),
                smooths = c(gev.priors$loc$smooth,
                            gev.priors$scale$smooth,
                            gev.priors$shape$smooth),
                beta = list(loc = c(26, 0.5),
                            scale = c(10, 0.2),
                            shape = gev.priors$shape$mean))

  thin = 15
  burn.in = 5000
  mciter = 10000

  # compute extremal-coefficient site weights
  f = fmadogram(data, coord, which=NULL)
  f.loess = loess(ext.coeff~dist, data.frame(f))
  d = as.matrix(dist(coord))
  wts = sapply(1:nrow(coord), function(i) {
    mean(nrow(coord)^(predict(f.loess, d[i,-i])-2))
  })

  res$wts = wts

  # draw posterior sample of return levels from posterior parameters
  mcmcRL = function(m) {
    mcRL = matrix(0, nrow = mciter, ncol = n.site)
    for(i in 1:mciter) {
      for(j in 1:n.site) {
        mcRL[i,j] = qgev(rl.p,
                         m$chain.loc[i,j+5],
                         m$chain.scale[i,j+5],
                         m$chain.shape[i,j+4])
      }
    }
    mcRL
  }


  #
  # model fit evaluation functions
  #

  coverage = function(truth, samples) {
    # compute empirical coverage

    m = mcmc(samples)

    df = data.frame(
      truth = as.numeric(truth),
      est = colMeans(m),
      est.L = HPDinterval(m)[,1],
      est.U = HPDinterval(m)[,2]
    ) %>% mutate(covered = (truth >= est.L) & (truth <= est.U))

    mean(df$covered)
  }

  fitdf = function(model, truth, samples) {
    ptEst = colMeans(samples)

    r = data.frame(
      model = model,
      coverage = coverage(truth, samples),
      mse = mean((ptEst - truth)^2),
      bias = mean(ptEst - truth),
      bias.rel = mean((ptEst-truth)/truth)*100,
      var = mean(apply(samples, 2, var))
    )

    r
  }


  #
  # generic model fitting script
  #

  res$fits = list(
      rl = data.frame(),
      loc = data.frame(),
      shape = data.frame(),
      scale = data.frame()
  )

  res$ests = data.frame()

  fiteval = function(mod) {
      # generic function for fitting and evaluating models
      #
      # Parameters:
      #  mod - name of model to fit

    if(mod=='latent') {
        mc <- latent(data, coord, loc.form = loc.form,
            scale.form = scale.form, shape.form = shape.form,
            hyper = hyper, prop = prop, start = start, n = mciter,
            burn.in = burn.in, thin = thin, use.log.link = TRUE)
    } else {
        params = list(
            'penalized.pc' = list(
                penalty = 1e-5, penaltyPOW = 1,
                penaltyAlpha = 2, penaltyBeta = 1, C = 1e-4,
                penaltyType = 5, penaltyPrior = 6
            ),
            'wtd' = list(
                penalty = 1e-5, penaltyPOW = .95,
                penaltyAlpha = 2, penaltyBeta = 1, C = 1e-4,
                penaltyType = -1, penaltyPrior = -1, wts = wts
            )
          )

        p = params[[mod]]

        mc <- latent.penalized(data, coord, loc.form = loc.form,
            scale.form = scale.form, shape.form = shape.form, hyper = hyper,
            prop = prop, start = start, n = mciter, burn.in = burn.in,
            thin = thin, penalty = p$penalty, penaltyPOW = p$penaltyPOW,
            penaltyAlpha = p$penaltyAlpha, penaltyBeta = p$penaltyBeta, C = p$C,
            tgtPen = .44, penaltyType = p$penaltyType,
            penaltyPrior = p$penaltyPrior, wts = p$wts, likType = p$likType,
            rp = rl, verbose = FALSE, use.log.link = TRUE, updateWts = FALSE)
    }

    mc.rl = mcmcRL(mc)

    res$fits$rl = rbind(res$fits$rl, fitdf(mod, theoretical.rl, mc.rl))
    res$fits$loc = rbind(res$fits$loc, fitdf(mod, locs, mc$chain.loc[,-(1:5)]))
    res$fits$shape = rbind(res$fits$shape, fitdf(mod, shapes, mc$chain.shape[,-(1:4)]))
    res$fits$scale = rbind(res$fits$scale, fitdf(mod, scales, mc$chain.scale[,-(1:5)]))

    HPDs = HPDinterval(mcmc(mc.rl))
    
    res$ests = rbind(res$ests,
        data.frame(
          model = mod,
          loc = colMeans(mc$chain.loc[,-(1:5)]),
          shape = colMeans(mc$chain.shape[,-(1:4)]),
          scale = colMeans(mc$chain.scale[,-(1:5)]),
          rl = colMeans(mc.rl),
          rl.var = apply(mc.rl, 2, var),
          rl.L = HPDs[,1],
          rl.U = HPDs[,2]
        )
    )

    res
  }

  #
  # actual model fitting
  #

  if(is.null(mods)) {
      mods = c('latent', 'penalized.pc', 'wtd')
  }

  for(m in mods) {
      res = fiteval(m)
  }

 res
}
