library(Rmpi)
library(snow)
library(doSNOW)
library(foreach)
library(iterators)
library(doRNG)

# identify where simulation code is stored
worker.script.path = 'analysis_fns.R'


#
# build and initialize MPI parallelism (optional)
#

cl = getMPIcluster()
ncores = length(cl)
registerDoSNOW(cl)

clusterExport(cl, ls())

source(worker.script.path)
clusterEvalQ(cl, source(worker.script.path))


#
# configure and run simulation
#

source(worker.script.path)

m = 1000

BR.config = list(
  'independent' = list(BR = F, lambda = .5, alpha = .5),
  'strong' = list(BR = T, lambda = .75, alpha = .25),
  'moderate' = list(BR = T, lambda = .5, alpha = .5),
  'weak' = list(BR = T, lambda = .25, alpha = .75)
)

sims = expand.grid(
  n = c(30, 50, 100),
  t = c(50, 100),
  dep = names(BR.config),
  rl = 100
)

end = ifelse(end==-1, nrow(sims), end)

# run all simulation configurations
res = foreach(s = iter(sims, by = 'row'), .combine='c', .errorhandling = 'remove') %do% {
  # run simulations for current configuration
  r = list( foreach(i = 1:m, .combine = 'c', .errorhandling = 'remove') %dorng% {
    r = sim(rl = s$rl, n.site = s$n, n.obs = s$t, gev.priors = GEV.CO.moderate,
            BR = BR.config[[s$dep]]$BR, 
            lambda = BR.config[[s$dep]]$lambda, 
            alpha = BR.config[[s$dep]]$alpha)
    r$dep = s$dep
    r
  })
  # clear seed information
  attr(r[[1]],'rng') = NULL
  # write scratch
  save.image(paste(paste(format(s), collapse = '-'), '.RData', sep=''))
  # output for merging
  r
}

stopCluster(cl)
mpi.quit()