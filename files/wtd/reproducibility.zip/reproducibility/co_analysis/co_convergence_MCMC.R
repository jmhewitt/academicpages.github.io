#!/usr/local/R/bin/Rscript

# generate data for assessing convergence of MCMC chain for CO analysis by 
# running the MCMC chain with initial values sampled from the prior 
# distributions.  save MCMC chains for later convergence analysis.

# read command line arguments
library(optparse)

#
# set defaults and read cmd line arguments
#

# specify cmd line options and defaults
option_list = list(
  make_option(c("--suffix"), default=FALSE, type='character',
              help="Specify the suffix of the output file")
)

# build cmd line parser
parser = OptionParser(usage="%prog [options]", option_list=option_list)

# parse command line arguments and attach to global environment
args = parse_args(parser)
attach(args)

# latent spatial extremes model
library(SpatialExtremes)
library(gaussquad)
library(orthopolynom)
# data reshaping
library(tidyr)
library(foreach)
library(iterators)
# data manipulation
library(dplyr)
library(fields)
# mcmc diagnostics
library(coda)
# reading bil files
library(raster)


# set file paths
rawDat = 'dat.RData'
prismDat = 'PRISM_ppt_30yr_normal_800mM2_annual_bil.bil'
prismDir = 'PRISM/'
krigScript = 'kriging.R'

# load reformatted raw data
load(rawDat)

#
# extract annual average precipitation at kriging grid locations
#

# load data
dir = getwd()
prism = raster(prismDat)
rm(dir)


# set seed
set.seed(suffix)

# crop to region around Colorado
prism = crop(prism, extent(-110, -101, 36, 42))

# extract data and build design matrix
stn.info$meanP = extract(prism, coord)/100

# center and scale covariate matrix
marg.cov[,4] = stn.info$meanP
marg.cov = scale(marg.cov)

# redo SpatialExtremes::gevmle function to return covariance estimates
gevmle = function (x, ..., method = "Nelder") 
{
  n <- length(x)
  param <- c("loc", "scale", "shape")
  nlgev <- function(loc, scale, shape) - sum(
    dgev(x, loc, scale, shape, log = TRUE), na.rm = TRUE)
  start <- c(loc = 0, scale = 0, shape = 0)
  start["scale"] <- sqrt(6 * var(x, na.rm = TRUE))/pi
  start["loc"] <- mean(x, na.rm = TRUE) - 0.58 * start["scale"]
  start <- start[!(param %in% names(list(...)))]
  nm <- names(start)
  l <- length(nm)
  f <- formals(nlgev)
  names(f) <- param
  m <- match(nm, param)
  formals(nlgev) <- c(f[m], f[-m])
  nllh <- function(p, ...) nlgev(p, ...)
  if (l > 1) 
    body(nllh) <- parse(text = paste("nlgev(", paste("p[", 
                                                     1:l, "]", collapse = ", "), ", ...)"))
  fixed.param <- list(...)[names(list(...)) %in% param]
  if (any(!(param %in% c(nm, names(fixed.param))))) 
    stop("unspecified parameters")
  opt <- optim(start, nllh, ..., method = method, hessian = T)
  param <- c(opt$par, unlist(fixed.param))
  names(param) <- c("loc", "scale", "shape")
  list(param = param,
       cov = solve(opt$hessian))
}


#
# develop starting estimates for MCMC chain
#


# marginal mle's for gev parameters
mle = foreach(r = iter(dat.wide, by='column'), .combine = 'rbind') %do% {
  gevmle(r)$param
}

# marginal covariances for gev parameters
cov = foreach(r = iter(dat.wide, by='column'), .combine = telefit:::abind3) %do% {
  gevmle(r)$cov
}


#
# get starting points for MCMC sampler
#

# weighted least squares covariance matrix for regression component
S11 <- diag(cov[1,1,])
S12 <- diag(cov[1,2,])
S13 <- diag(cov[1,3,])
S22 <- diag(cov[2,2,])
S23 <- diag(cov[2,3,])
S33 <- diag(cov[3,3,])
Sigma <- rbind(
  cbind(S11, S12, S13),
  cbind(S12, S22, S23),
  cbind(S13, S23, S33))
rm(S11, S12, S13, S22, S23, S33)

# mean precip covariate in mean
numStn = nrow(stn.info)
X <- cbind( c(rep(1, numStn), rep(0, 2*numStn)), 
            c(marg.cov[,4], rep(0, 2*numStn)),
            c(rep(0, numStn), rep(1, numStn), rep(0, numStn)),
            c(rep(0, numStn), marg.cov[,4], rep(0, numStn)),
            c(rep(0, 2*numStn), rep(1, numStn)),
            c(rep(0, 2*numStn), marg.cov[,4]))


# WLS estimates for mean structure
beta <- solve(t(X) %*% solve(Sigma, X)) %*% t(X) %*% solve(Sigma, as.numeric(mle))
rownames(beta) = c('mu.intercept', 'mu.precip', 
                   'sigma.intercept', 'sigma.precip',
                   'xi.intercept', 'xi.precip')

rm(Sigma, X, numStn, r)


# priors to go along with these settings


#
# compute weights
#

# estimate f madogram
f = fmadogram(as.matrix(dat.wide), as.matrix(coord), which=NULL)
f[,1] = rdist.earth(coord, miles = F)[upper.tri(matrix(0,nrow=71,ncol=71))]
f.loess = loess(ext.coeff~dist, data.frame(f))

# compute weights
d = as.matrix(rdist.earth(coord, miles = F))
wts = sapply(1:nrow(coord), function(i) {
  mean(ncol(dat.wide)^(predict(f.loess, d[i,-i])-2))
})


#
# set priors and MCMC settings
#

# the gamma distributions are set so that the prior mode covers the 
# variogram estimates for the covariance parameters
hyper = list(
  sills = list(loc = c(2,60), scale = c(2,.1), shape = c(2,.03)),
  ranges = list(loc = c(2,.5), scale = c(2,.25), shape = c(2,.1)),
  smooths = list(loc = c(2,1), scale = c(2,1), shape = c(2,1)),
  betaMeans = list(loc = rep(0,2), scale = rep(0,2), shape = rep(0,2)),
  betaIcov = list(loc = diag(rep(1e-2,2)), scale = diag(rep(1e-2,2)), 
                  shape = diag(rep(1e-2,2)))
)

prop = list(
  # loc, scale, shape
  gev = c(1.45, .25, .11),
  ranges = c(3e-1, 4e-1, 6e-1),
  smooths = c(.12, .1, .15)
)


# random starts, for assessing convergence
start = list(
  sills = c(1/rgamma(1, shape = hyper$sills$loc[1], 
                        rate = hyper$sills$loc[2]),
            1/rgamma(1, shape = hyper$sills$scale[1], 
                        rate = hyper$sills$scale[2]),
            1/rgamma(1, shape = hyper$sills$shape[1], 
                        rate = hyper$sills$shape[2])),
  ranges = c(rgamma(1, shape = hyper$ranges$loc[1], 
                       scale = hyper$ranges$loc[2]),
             rgamma(1, shape = hyper$ranges$scale[1], 
                       scale = hyper$ranges$scale[2]),
             rgamma(1, shape = hyper$ranges$shape[1], 
                       scale = hyper$ranges$shape[2])),
  smooths = c(rgamma(1, shape = hyper$smooths$loc[1], 
                        scale = hyper$smooths$loc[2]),
              rgamma(1, shape = hyper$smooths$scale[1], 
                        scale = hyper$smooths$scale[2]),
              rgamma(1, shape = hyper$smooths$shape[1], 
                        scale = hyper$smooths$shape[2])),
  
  beta = list(loc = rnorm(n=2, sd = sqrt(1/diag(hyper$betaIcov$loc))),
              scale = rnorm(n=2, sd = sqrt(1/diag(hyper$betaIcov$scale))),
              shape = rnorm(n=2, sd = sqrt(1/diag(hyper$betaIcov$shape)))
  ))


n.samples = 10000
thin = 300
burn.in = 2000


loc.form <- y ~ meanP
scale.form <- y ~ meanP
shape.form <- y ~ meanP

data = as.matrix(dat.wide)

rl = 100

#
# fit latent spatial model(s)
#

fit.wtd =    latent.penalized(data, coord, marg.cov = marg.cov, cov.mod = 'whitmat', 
                     hyper = hyper, prop = prop, start = start, loc.form = loc.form, 
                     scale.form = scale.form, shape.form = shape.form, 
                     n = n.samples, thin = thin, burn.in = burn.in, 
                     penalty = 1e-5, penaltyPOW = .95, penaltyAlpha = 2,
                     penaltyBeta = 1, C = 1e-4, tgtPen = .44, 
                     penaltyType = -1, penaltyPrior = -1, rp = rl, verbose = F,
                     wts = wts, use.log.link = TRUE, updateWts = FALSE)

#
# compute return levels
#

# user posterior sample to estimate return levels
mcmcRL = function(m) {
  rl.p = 1 - 1/rl
  mciter = nrow(m$chain.loc)
  n.site = ncol(m$data)
  mcRL = matrix(0, nrow = mciter, ncol = n.site)
  for(i in 1:mciter) {
    for(j in 1:n.site) {
      mcRL[i,j] = qgev(rl.p, 
                       m$chain.loc[i,j+5], 
                       m$chain.scale[i,j+5], 
                       m$chain.shape[i,j+5])
    }
  }
  mcRL
}

fit.rl.wtd = mcmcRL(fit.wtd)

save(fit.wtd, fit.rl.wtd, file = paste('convergence', suffix, '.RData', sep = ''))