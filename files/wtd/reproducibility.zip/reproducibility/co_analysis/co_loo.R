# CO analyis with leave-several-out model comparison

# latent spatial extremes model
library(SpatialExtremes)
library(gaussquad)
library(orthopolynom)
# data reshaping
library(tidyr)
# data manipulation
library(dplyr)
# efficient looping
library(foreach)
library(iterators)
library(doMC)
library(doRNG)
library(snow)
library(doSNOW)
library(itertools)
# variograms
library(geoR)
library(fields)
# mcmc diagnostics
library(coda)
# reading bil files
library(raster)

registerDoMC(2)

# set file paths
rawDat = 'dat.RData'
prismDat = 'PRISM_ppt_30yr_normal_800mM2_annual_bil.bil'
prismDir = 'PRISM/'
krigScript = 'kriging.R'

# load reformatted raw data
load(rawDat)

#
# extract annual average precipitation at kriging grid locations
#

# load data
dir = getwd()
setwd(prismDir)
prism = raster(prismDat)
setwd(dir)
rm(dir)

# crop to region around Colorado
prism = crop(prism, extent(-110, -101, 36, 42))

# extract data and build design matrix
stn.info$meanP = extract(prism, coord)/100

# center and scale covariate matrix
marg.cov[,4] = stn.info$meanP
marg.cov = scale(marg.cov)

# create holdout set
test.cities = c('Greeley', 'Longmont', 'Nederland', 'Aurora', 'Parker', 
                'Pueblo', 'Penrose')
test.inds = stn.info$city %in% test.cities

stn.info.test = stn.info[test.inds,]
coord.test = coord[test.inds,]
marg.cov.test = marg.cov[test.inds,]
dat.test = dat.wide[,test.inds]

stn.info = stn.info[!test.inds,]
coord = coord[!test.inds,]
marg.cov = marg.cov[!test.inds,]
dat.wide = dat.wide[,!test.inds]


# redo SpatialExtremes::gevmle function to return covariance estimates
gevmle = function (x, ..., method = "Nelder") 
{
  n <- length(x)
  param <- c("loc", "scale", "shape")
  nlgev <- function(loc, scale, shape) - sum(
    dgev(x, loc, scale, shape, log = TRUE), na.rm = TRUE)
  start <- c(loc = 0, scale = 0, shape = 0)
  start["scale"] <- sqrt(6 * var(x, na.rm = TRUE))/pi
  start["loc"] <- mean(x, na.rm = TRUE) - 0.58 * start["scale"]
  start <- start[!(param %in% names(list(...)))]
  nm <- names(start)
  l <- length(nm)
  f <- formals(nlgev)
  names(f) <- param
  m <- match(nm, param)
  formals(nlgev) <- c(f[m], f[-m])
  nllh <- function(p, ...) nlgev(p, ...)
  if (l > 1) 
    body(nllh) <- parse(text = paste("nlgev(", paste("p[", 
                                                     1:l, "]", collapse = ", "), ", ...)"))
  fixed.param <- list(...)[names(list(...)) %in% param]
  if (any(!(param %in% c(nm, names(fixed.param))))) 
    stop("unspecified parameters")
  opt <- optim(start, nllh, ..., method = method, hessian = T)
  param <- c(opt$par, unlist(fixed.param))
  names(param) <- c("loc", "scale", "shape")
  list(param = param,
       cov = solve(opt$hessian))
}


#
# develop starting estimates for MCMC chain
#


# marginal mle's for gev parameters
mle = foreach(r = iter(dat.wide, by='column'), .combine = 'rbind') %do% {
  gevmle(r)$param
}

# marginal covariances for gev parameters
cov = foreach(r = iter(dat.wide, by='column'), .combine = telefit:::abind3) %do% {
  gevmle(r)$cov
}


#
# get starting points for MCMC sampler
#

# weighted least squares covariance matrix for regression component
S11 <- diag(cov[1,1,])
S12 <- diag(cov[1,2,])
S13 <- diag(cov[1,3,])
S22 <- diag(cov[2,2,])
S23 <- diag(cov[2,3,])
S33 <- diag(cov[3,3,])
Sigma <- rbind(
  cbind(S11, S12, S13),
  cbind(S12, S22, S23),
  cbind(S13, S23, S33))
rm(S11, S12, S13, S22, S23, S33)

# mean precip covariate in mean
numStn = nrow(stn.info)
X <- cbind( c(rep(1, numStn), rep(0, 2*numStn)), 
            c(marg.cov[,4], rep(0, 2*numStn)),
            c(rep(0, numStn), rep(1, numStn), rep(0, numStn)),
            c(rep(0, numStn), marg.cov[,4], rep(0, numStn)),
            c(rep(0, 2*numStn), rep(1, numStn)),
            c(rep(0, 2*numStn), marg.cov[,4]))


# WLS estimates for mean structure
beta <- solve(t(X) %*% solve(Sigma, X)) %*% t(X) %*% solve(Sigma, as.numeric(mle))
rownames(beta) = c('mu.intercept', 'mu.precip', 
                   'sigma.intercept', 'sigma.precip',
                   'xi.intercept', 'xi.precip')

rm(Sigma, X, r)

# variogram-based estimates of covariance function parameters for GEV location
v.mu = variog(coords = coord, data = mle[,1])
# plot(v.mu)
v.mu.fit = variofit(vario = v.mu, ini.cov.pars = c(60, 1),
         cov.model = 'matern', fix.nugget = T, fix.kappa = F)
# lines(v.mu$u, v.mu.fit$cov.pars[1]*
#         (1-matern(u = v.mu$u, phi = v.mu.fit$cov.pars[2], kappa = v.mu.fit$kappa)) )

# variogram-based estimates of covariance function parameters for GEV shape
v.sigma = variog(coords = coord, data = log(mle[,2]))
# plot(v.sigma)
v.sigma.fit = variofit(vario = v.sigma, ini.cov.pars = c(.1, 1),
                    cov.model = 'matern', fix.nugget = T, fix.kappa = F)
# lines(v.sigma$u, v.sigma.fit$cov.pars[1]*
#         (1-matern(u = v.sigma$u, phi = v.sigma.fit$cov.pars[2],
#                   kappa = v.sigma.fit$kappa)) )

# variogram-based estimates of covariance function parameters for GEV scale
v.xi = variog(coords = coord, data = mle[,3])
# plot(v.xi)
v.xi.fit = variofit(vario = v.xi, ini.cov.pars = c(.03, .5),
                       cov.model = 'matern', fix.nugget = T, fix.kappa = F)
# lines(v.xi$u, v.xi.fit$cov.pars[1]*
#         (1-matern(u = v.xi$u, phi = v.xi.fit$cov.pars[2], 
#                   kappa = v.xi.fit$kappa)) )

rm(v.mu, v.sigma, v.xi, cov, gevmle)


# priors to go along with these settings


#
# compute weights
#

# estimate f madogram
f = fmadogram(as.matrix(dat.wide), as.matrix(coord), which=NULL)
f[,1] = rdist.earth(coord, miles = F)[upper.tri(matrix(0,
                                                       nrow=numStn,
                                                       ncol=numStn))]
f.loess = loess(ext.coeff~dist, data.frame(f))

# compute weights
d = as.matrix(rdist.earth(coord, miles = F))
wts = sapply(1:nrow(coord), function(i) {
  mean(ncol(dat.wide)^(predict(f.loess, d[i,-i])-2))
})


#
# set priors and MCMC settings
#

# the gamma distributions are set so that the prior mode covers the 
# variogram estimates for the covariance parameters
hyper = list(
  sills = list(loc = c(2,60), scale = c(2,.1), shape = c(2,.03)),
  ranges = list(loc = c(2,.5), scale = c(2,.25), shape = c(2,.1)),
  smooths = list(loc = c(2,1), scale = c(2,1), shape = c(2,1)),
  betaMeans = list(loc = rep(0,2), scale = rep(0,2), shape = rep(0,2)),
  betaIcov = list(loc = diag(rep(1e-2,2)), scale = diag(rep(1e-2,2)), 
                  shape = diag(rep(1e-2,2)))
)

prop = list(
  # loc, scale, shape
  gev = c(1.45, .25, .11),
  ranges = c(3e-1, 4e-1, 6e-1),
  smooths = c(.12, .1, .15)
)

start = list(
  sills = c(v.mu.fit$cov.pars[1],
            v.sigma.fit$cov.pars[1],
            v.xi.fit$cov.pars[1]),
  ranges = c(v.mu.fit$cov.pars[2],
             v.sigma.fit$cov.pars[2],
             v.xi.fit$cov.pars[2]),
  smooths = c(v.mu.fit$kappa,
              v.sigma.fit$kappa,
              v.xi.fit$kappa),
  beta = list(loc = beta[1:2],
              scale = beta[3:4],
              shape = beta[5:6]
))

n.samples = 10000
thin = 300
burn.in = 2000

loc.form <- y ~ meanP
scale.form <- y ~ meanP
shape.form <- y ~ meanP

data = as.matrix(dat.wide)

rl = 100

#
# fit latent spatial model(s)
#

ret = foreach(i=c(1,2)) %dorng% { 
  if(i==1) { # unpenalized
    latent(data, coord, marg.cov = marg.cov, cov.mod = 'whitmat', hyper = hyper, 
           prop = prop, start = start, loc.form = loc.form, scale.form = scale.form,
           shape.form = shape.form, n = n.samples, thin = thin, burn.in = burn.in,
           use.log.link = TRUE)
  } else if(i==2) { # weighted 
    latent.penalized(data, coord, marg.cov = marg.cov, cov.mod = 'whitmat', 
                     hyper = hyper, prop = prop, start = start, loc.form = loc.form, 
                     scale.form = scale.form, shape.form = shape.form, 
                     n = n.samples, thin = thin, burn.in = burn.in, 
                     penalty = 1e-5, penaltyPOW = .95, penaltyAlpha = 2,
                     penaltyBeta = 1, C = 1e-4, tgtPen = .44, 
                     penaltyType = -1, penaltyPrior = -1, rp = rl, verbose = F,
                     wts = wts, use.log.link = TRUE, updateWts = FALSE)
  }
}

fit = ret[[1]]
fit.wtd = ret[[2]]
rm(ret)


#
# compute out of sample fit statistics
#

# initialize parallelism
ncores = 8
cl = makeCluster(ncores, type = "SOCK")
registerDoSNOW(cl)


#
# extract annual average precipitation at out of sample grid locations
#

# set test coordinates
coord.pred = coord.test

# extract data and build design matrix
ppt.pred = marg.cov.test[,4]
dsn.pred = cbind(1, ppt.pred)

#
# kriging functions
#

composition.krig = function(fit, coord.pred, dsn.pred, burn=1, rl = 100, 
                            ncores=1) {
  # Return composition samples of kriged marginal parameters.  
  #
  # Note: This function assumes a known/fixed structure for the MCMC output,
  #  in particular, where the sampled covariance parameters start and end.
  #
  # Parameters:
  #  fit - fitted model
  #  cord.pred - kriging locations
  #  dsn.pred - design matrix for kriging locations
  #  burn - number of posterior samples to discard (Note, MCMC output from 
  #   SpatialExtremes::latent functions has already been burned-in)
  #  rl - return level to compute
  #  ncores - if a parallel backend is registered, number of cores to use
  
  krig.samp = function(x, d.coord, d.pred, d.cross, cov.mod, sill, range, 
                       smooth, mean.x, mean.pred){
    # Samples from the kriging distribution
    #
    # Parameters:
    #  x - given data
    #  d.coord - distances between observation coordinates
    #  d.pred - distances between kriging locations
    #  d.cross - distances between observation and kriging locations such that
    #   each row represents one kriging location
    #  cov.mod - covariance model to use 
    #  sill, range, smooth - parameters for the covariance model
    #  mean.x, mean.pred - mean value for field at observed and kriging coords.
    #
    # Return:
    #  a sample of the field from the kriging distribution at kriging locations
    
    #
    # compute base spatial covariances and decompositions
    #
    
    Sigma.coord = covariance(cov.mod = cov.mod, nugget = 0, sill = sill, 
                             range = range, smooth = smooth, plot = F, 
                             dist = d.coord)$cov.val
    
    Sigma.pred = covariance(cov.mod = cov.mod, nugget = 0, sill = sill, 
                            range = range, smooth = smooth, plot = F, 
                            dist = d.pred)$cov.val
    
    Sigma.cross = covariance(cov.mod = cov.mod, nugget = 0, sill = sill, 
                             range = range, smooth = smooth, plot = F, 
                             dist = d.cross)$cov.val
    
    Sigma.coord.chol = chol(Sigma.coord)
    
    
    #
    # compute kriging distribution parameters and decompositions
    #
    
    mu.cond = mean.pred + Sigma.cross %*% 
      backsolve(Sigma.coord.chol, forwardsolve(t(Sigma.coord.chol), x - mean.x))
    
    Sigma.cond = forwardsolve(t(Sigma.coord.chol), t(Sigma.cross))
    Sigma.cond = Sigma.pred - t(Sigma.cond) %*% Sigma.cond
    
    Sigma.cond.chol = chol(Sigma.cond)
    
    # sample
    mu.cond + t(Sigma.cond.chol) %*% rnorm(nrow(d.pred))
    
  }
  
  
  #
  # compute distances
  #
  
  d = as.matrix(dist(rbind(coord.pred, fit$coord)))
  d.coord = d[(nrow(coord.pred)+1):nrow(d), (nrow(coord.pred)+1):nrow(d)]
  d.pred = d[1:nrow(coord.pred), 1:nrow(coord.pred)]
  d.cross = d[1:nrow(coord.pred), (nrow(coord.pred)+1):nrow(d)]
  
  #
  # Draw composition samples
  #
  
  p = 1 - 1/rl
  
  nsamp = nrow(fit$chain.loc)-burn+1
  
  krig.all = function() { 
    foreach(inds = ichunk(1:nsamp, chunkSize = ceiling(nsamp/ncores)),
            .combine = 'rbind', .export = c('fit', 'd.coord', 'd.pred', 'p',
                                            'd.cross', 'krig.samp', 'burn',
                                            'dsn.pred', 'dat.test'),
            .packages = 'SpatialExtremes', .errorhandling='remove') %dorng% {
    foreach(inds = unlist(inds), .combine = 'rbind', 
            .errorhandling = 'remove') %do% {
              
      chain.loc = fit$chain.loc
      chain.scale = fit$chain.scale
      chain.scale[,-(1:5)] = log(chain.scale[,-(1:5)])
      chain.shape = fit$chain.shape
      
      tmp.loc = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      tmp.scale = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      tmp.shape = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      tmp.rl = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      tmp.ll = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      
      colnames(tmp.loc) = paste('loc', 1:nrow(d.pred), sep='')
      colnames(tmp.scale) = paste('scale', 1:nrow(d.pred), sep='')
      colnames(tmp.shape) = paste('shape', 1:nrow(d.pred), sep='')
      colnames(tmp.rl) = paste('rl', 1:nrow(d.pred), sep='')
      
      krig.single = function(chain, i, dsn.dat) {
        
        betas.ind = 1:2
        sill.ind = 3
        range.ind = 4
        smooth.ind = 5
        sample.ind = burn - 1 + i
        
        krig.samp(x = chain[sample.ind, 
                            -c(betas.ind, sill.ind, range.ind, smooth.ind)], 
                  d.coord = d.coord,
                  d.pred = d.pred, d.cross = d.cross, cov.mod = fit$cov.mod[1],
                  sill = chain[sample.ind, sill.ind], 
                  range = chain[sample.ind, range.ind],
                  smooth = chain[sample.ind, smooth.ind], 
                  mean.x = dsn.dat %*% chain[sample.ind,betas.ind], 
                  mean.pred = dsn.pred %*% chain[sample.ind,betas.ind])
      }
      
      for(j in 1:length(inds)) {
        i = inds[j]
        tmp.scale[j,] = exp(krig.single(chain.scale, i, fit$scale.dsgn.mat))
        tmp.loc[j,] = krig.single(chain.loc, i, fit$loc.dsgn.mat)
        tmp.shape[j,] = krig.single(chain.shape, i, fit$shape.dsgn.mat)
        tmp.rl[j,] = sapply(1:nrow(d.pred), function(i) {
          if(tmp.scale[j,i]>0) {
            qgev(p=p, loc = tmp.loc[j,i], scale = tmp.scale[j,i],
                 shape = tmp.shape[j,i])
          } else {
            NA
          }
        })
        tmp.ll[j,] = sapply(1:nrow(d.pred), function(i) {
          if(tmp.scale[j,i]>0) {
            sum(dgev(x = dat.test[,i], loc = tmp.loc[j,i],
                     scale = tmp.scale[j,i], shape = tmp.shape[j,i],
                     log = TRUE), na.rm = TRUE)
          } else {
            NA
          }
        })
      }
      cbind(tmp.loc, tmp.scale, tmp.shape, tmp.rl, tmp.ll)
    }
   }
  }
  
  krig = krig.all()
  
  locs.krig = krig[,1:nrow(d.pred)]
  scales.krig = krig[,(1:nrow(d.pred)) + nrow(d.pred)]
  shapes.krig = krig[,(1:nrow(d.pred)) + 2*nrow(d.pred)]
  rl.krig = krig[,(1:nrow(d.pred)) + 3*nrow(d.pred)]
  ll.krig = krig[,(1:nrow(d.pred)) + 4*nrow(d.pred)]
  
  list(locs = locs.krig, scales = scales.krig, shapes = shapes.krig, 
       rl = rl.krig, ll = ll.krig, coord = coord.pred)
}


fit.krig = composition.krig(fit, coord.pred, dsn.pred, burn = 1, 
                            ncores = ncores)
fit.wtd.krig = composition.krig(fit.wtd, coord.pred, dsn.pred, burn = 1, 
                                ncores = ncores)


# save key results
save(fit, fit.wtd, fit.krig, fit.wtd.krig, file = 'co_loo.RData')



#
# analyze results
#

load('co_loo.RData')

# the posterior log score shows that the log-likelihood is almost always higher 
df = rbind(
  WTD = apply(fit.wtd.krig$ll, 2, function(x) { mean(x[is.finite(x)])}),
  UNWTD = apply(fit.krig$ll, 2, function(x) { mean(x[is.finite(x)])})
)
colnames(df) = test.cities
df

df[1,]-df[2,]
