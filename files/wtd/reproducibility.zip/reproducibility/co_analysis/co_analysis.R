# latent spatial extremes model
library(SpatialExtremes)
library(gaussquad)
library(orthopolynom)
# data reshaping
library(tidyr)
# data manipulation
library(dplyr)
# efficient looping
library(foreach)
library(iterators)
library(doMC)
library(doRNG)
# variograms
library(geoR)
library(fields)
# mcmc diagnostics
library(coda)
# reading bil files
library(raster)

registerDoMC(2)

# set file paths
rawDat = 'dat.RData'
prismDat = 'PRISM_ppt_30yr_normal_800mM2_annual_bil.bil'
prismDir = 'PRISM/'
krigScript = 'kriging.R'

# load reformatted raw data
load(rawDat)

#
# extract annual average precipitation at kriging grid locations
#

# load data
dir = getwd()
setwd(prismDir)
prism = raster(prismDat)
setwd(dir)
rm(dir)

# crop to region around Colorado
prism = crop(prism, extent(-110, -101, 36, 42))

# extract data and build design matrix
stn.info$meanP = extract(prism, coord)/100

# center and scale covariate matrix
marg.cov[,4] = stn.info$meanP
marg.cov = scale(marg.cov)

# redo SpatialExtremes::gevmle function to return covariance estimates
gevmle = function (x, ..., method = "Nelder") 
{
  n <- length(x)
  param <- c("loc", "scale", "shape")
  nlgev <- function(loc, scale, shape) - sum(
    dgev(x, loc, scale, shape, log = TRUE), na.rm = TRUE)
  start <- c(loc = 0, scale = 0, shape = 0)
  start["scale"] <- sqrt(6 * var(x, na.rm = TRUE))/pi
  start["loc"] <- mean(x, na.rm = TRUE) - 0.58 * start["scale"]
  start <- start[!(param %in% names(list(...)))]
  nm <- names(start)
  l <- length(nm)
  f <- formals(nlgev)
  names(f) <- param
  m <- match(nm, param)
  formals(nlgev) <- c(f[m], f[-m])
  nllh <- function(p, ...) nlgev(p, ...)
  if (l > 1) 
    body(nllh) <- parse(text = paste("nlgev(", paste("p[", 
                                                     1:l, "]", collapse = ", "), ", ...)"))
  fixed.param <- list(...)[names(list(...)) %in% param]
  if (any(!(param %in% c(nm, names(fixed.param))))) 
    stop("unspecified parameters")
  opt <- optim(start, nllh, ..., method = method, hessian = T)
  param <- c(opt$par, unlist(fixed.param))
  names(param) <- c("loc", "scale", "shape")
  list(param = param,
       cov = solve(opt$hessian))
}


#
# develop starting estimates for MCMC chain
#


# marginal mle's for gev parameters
mle = foreach(r = iter(dat.wide, by='column'), .combine = 'rbind') %do% {
  gevmle(r)$param
}

# marginal covariances for gev parameters
cov = foreach(r = iter(dat.wide, by='column'), .combine = telefit:::abind3) %do% {
  gevmle(r)$cov
}


#
# get starting points for MCMC sampler
#

# weighted least squares covariance matrix for regression component
S11 <- diag(cov[1,1,])
S12 <- diag(cov[1,2,])
S13 <- diag(cov[1,3,])
S22 <- diag(cov[2,2,])
S23 <- diag(cov[2,3,])
S33 <- diag(cov[3,3,])
Sigma <- rbind(
  cbind(S11, S12, S13),
  cbind(S12, S22, S23),
  cbind(S13, S23, S33))
rm(S11, S12, S13, S22, S23, S33)

# mean precip covariate in mean
numStn = nrow(stn.info)
X <- cbind( c(rep(1, numStn), rep(0, 2*numStn)), 
            c(marg.cov[,4], rep(0, 2*numStn)),
            c(rep(0, numStn), rep(1, numStn), rep(0, numStn)),
            c(rep(0, numStn), marg.cov[,4], rep(0, numStn)),
            c(rep(0, 2*numStn), rep(1, numStn)),
            c(rep(0, 2*numStn), marg.cov[,4]))


# WLS estimates for mean structure
beta <- solve(t(X) %*% solve(Sigma, X)) %*% t(X) %*% solve(Sigma, as.numeric(mle))
rownames(beta) = c('mu.intercept', 'mu.precip', 
                   'sigma.intercept', 'sigma.precip',
                   'xi.intercept', 'xi.precip')

rm(Sigma, X, numStn, r)

# variogram-based estimates of covariance function parameters for GEV location
v.mu = variog(coords = coord, data = mle[,1])
# plot(v.mu)
v.mu.fit = variofit(vario = v.mu, ini.cov.pars = c(60, 1),
         cov.model = 'matern', fix.nugget = T, fix.kappa = F)
# lines(v.mu$u, v.mu.fit$cov.pars[1]*
#         (1-matern(u = v.mu$u, phi = v.mu.fit$cov.pars[2], kappa = v.mu.fit$kappa)) )

# variogram-based estimates of covariance function parameters for GEV shape
v.sigma = variog(coords = coord, data = log(mle[,2]))
# plot(v.sigma)
v.sigma.fit = variofit(vario = v.sigma, ini.cov.pars = c(8, 1),
                    cov.model = 'matern', fix.nugget = T, fix.kappa = F)
# lines(v.sigma$u, v.sigma.fit$cov.pars[1]*
#         (1-matern(u = v.sigma$u, phi = v.sigma.fit$cov.pars[2], 
#                   kappa = v.sigma.fit$kappa)) )

# variogram-based estimates of covariance function parameters for GEV scale
v.xi = variog(coords = coord, data = mle[,3])
# plot(v.xi)
v.xi.fit = variofit(vario = v.xi, ini.cov.pars = c(.03, .5),
                       cov.model = 'matern', fix.nugget = T, fix.kappa = F)
# lines(v.xi$u, v.xi.fit$cov.pars[1]*
#         (1-matern(u = v.xi$u, phi = v.xi.fit$cov.pars[2], 
#                   kappa = v.xi.fit$kappa)) )

rm(v.mu, v.sigma, v.xi, cov, gevmle)


# priors to go along with these settings


#
# compute weights
#

# estimate f madogram
f = fmadogram(as.matrix(dat.wide), as.matrix(coord), which=NULL)
f[,1] = rdist.earth(coord, miles = F)[upper.tri(matrix(0,nrow=71,ncol=71))]
f.loess = loess(ext.coeff~dist, data.frame(f))

# compute weights
d = as.matrix(rdist.earth(coord, miles = F))
wts = sapply(1:nrow(coord), function(i) {
  mean(ncol(dat.wide)^(predict(f.loess, d[i,-i])-2))
})


#
# set priors and MCMC settings
#

# the gamma distributions are set so that the prior mode covers the 
# variogram estimates for the covariance parameters
hyper = list(
  sills = list(loc = c(2,60), scale = c(2,.1), shape = c(2,.03)),
  ranges = list(loc = c(2,.5), scale = c(2,.25), shape = c(2,.1)),
  smooths = list(loc = c(2,1), scale = c(2,1), shape = c(2,1)),
  betaMeans = list(loc = rep(0,2), scale = rep(0,2), shape = rep(0,2)),
  betaIcov = list(loc = diag(rep(1e-2,2)), scale = diag(rep(1e-2,2)), 
                  shape = diag(rep(1e-2,2)))
)

prop = list(
  # loc, scale, shape
  gev = c(1.45, .25, .11),
  ranges = c(3e-1, 4e-1, 6e-1),
  smooths = c(.12, .1, .15)
)

start = list(
  sills = c(v.mu.fit$cov.pars[1],
            v.sigma.fit$cov.pars[1],
            v.xi.fit$cov.pars[1]),
  ranges = c(v.mu.fit$cov.pars[2],
             v.sigma.fit$cov.pars[2],
             v.xi.fit$cov.pars[2]),
  smooths = c(v.mu.fit$kappa,
              v.sigma.fit$kappa,
              v.xi.fit$kappa),
  beta = list(loc = beta[1:2],
              scale = beta[3:4],
              shape = beta[5:6]
))

n.samples = 10000
thin = 300
burn.in = 2000

loc.form <- y ~ meanP
scale.form <- y ~ meanP
shape.form <- y ~ meanP

data = as.matrix(dat.wide)

rl = 100

#
# fit latent spatial model(s)
#

ret = foreach(i=c(1,2)) %dorng% { 
  if(i==1) { # unpenalized
    latent(data, coord, marg.cov = marg.cov, cov.mod = 'whitmat', hyper = hyper, 
           prop = prop, start = start, loc.form = loc.form, scale.form = scale.form,
           shape.form = shape.form, n = n.samples, thin = thin, burn.in = burn.in,
           use.log.link = TRUE)
  } else if(i==2) { # weighted 
    latent.penalized(data, coord, marg.cov = marg.cov, cov.mod = 'whitmat', 
                     hyper = hyper, prop = prop, start = start, loc.form = loc.form, 
                     scale.form = scale.form, shape.form = shape.form, 
                     n = n.samples, thin = thin, burn.in = burn.in, 
                     penalty = 1e-5, penaltyPOW = .95, penaltyAlpha = 2,
                     penaltyBeta = 1, C = 1e-4, tgtPen = .44, 
                     penaltyType = -1, penaltyPrior = -1, rp = rl, verbose = F,
                     wts = wts, use.log.link = TRUE, updateWts = FALSE)
  }
}

fit = ret[[1]]
fit.wtd = ret[[2]]
rm(ret)

#
# compute return levels
#

# user posterior sample to estimate return levels
mcmcRL = function(m) {
  rl.p = 1 - 1/rl
  mciter = nrow(m$chain.loc)
  n.site = ncol(m$data)
  mcRL = matrix(0, nrow = mciter, ncol = n.site)
  for(i in 1:mciter) {
    for(j in 1:n.site) {
      mcRL[i,j] = qgev(rl.p, 
                       m$chain.loc[i,j+5], 
                       m$chain.scale[i,j+5], 
                       m$chain.shape[i,j+5])
    }
  }
  mcRL
}

fit.rl = mcmcRL(fit)
fit.rl.wtd = mcmcRL(fit.wtd)

rlSum = function(m) {
  list(
    est = colMeans(m),
    sd = apply(m, 2, sd),
    hpd = HPDinterval(mcmc(m))
  )
}

rl = rlSum(fit.rl)
rl.wtd = rlSum(fit.rl.wtd)

# krig return level estimates
source(krigScript)