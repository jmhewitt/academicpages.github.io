# kriging predictors for return levels

library(SpatialExtremes)
library(snow)
library(doRNG)
library(doSNOW)
library(foreach)
library(itertools)
# reading bil files
library(raster)

# initialize parallelism
ncores = 8
cl = makeCluster(ncores, type = "SOCK")
registerDoSNOW(cl)

# create kriging grid
nlon = 35
nlat = 35
coord.pred = expand.grid(Lon = seq(min(coord$Lon), max(coord$Lon), 
                                   length.out = nlon),
                         Lat = seq(min(coord$Lat), max(coord$Lat),
                                   length.out = nlat))

#
# extract annual average precipitation at kriging grid locations
#

# crop to region around Colorado
prism = crop(prism, extent(-110, -101, 36, 42))

# extract data and build design matrix
ppt.pred = extract(prism, coord.pred)/100
dsn.pred = cbind(1, ppt.pred)

#
# kriging functions
#

composition.krig = function(fit, coord.pred, dsn.pred, burn=1, rl = 100, 
                            ncores=1) {
  # Return composition samples of kriged marginal parameters.  
  #
  # Note: This function assumes a known/fixed structure for the MCMC output,
  #  in particular, where the sampled covariance parameters start and end.
  #
  # Parameters:
  #  fit - fitted model
  #  cord.pred - kriging locations
  #  dsn.pred - design matrix for kriging locations
  #  burn - number of posterior samples to discard (Note, MCMC output from 
  #   SpatialExtremes::latent functions has already been burned-in)
  #  rl - return level to compute
  #  ncores - if a parallel backend is registered, number of cores to use
  
  krig.samp = function(x, d.coord, d.pred, d.cross, cov.mod, sill, range, 
                       smooth, mean.x, mean.pred){
    # Samples from the kriging distribution
    #
    # Parameters:
    #  x - given data
    #  d.coord - distances between observation coordinates
    #  d.pred - distances between kriging locations
    #  d.cross - distances between observation and kriging locations such that
    #   each row represents one kriging location
    #  cov.mod - covariance model to use 
    #  sill, range, smooth - parameters for the covariance model
    #  mean.x, mean.pred - mean value for field at observed and kriging coords.
    #
    # Return:
    #  a sample of the field from the kriging distribution at kriging locations
    
    #
    # compute base spatial covariances and decompositions
    #
    
    Sigma.coord = covariance(cov.mod = cov.mod, nugget = 0, sill = sill, 
                             range = range, smooth = smooth, plot = F, 
                             dist = d.coord)$cov.val
    
    Sigma.pred = covariance(cov.mod = cov.mod, nugget = 0, sill = sill, 
                            range = range, smooth = smooth, plot = F, 
                            dist = d.pred)$cov.val
    
    Sigma.cross = covariance(cov.mod = cov.mod, nugget = 0, sill = sill, 
                             range = range, smooth = smooth, plot = F, 
                             dist = d.cross)$cov.val
    
    Sigma.coord.chol = chol(Sigma.coord)
    
    
    #
    # compute kriging distribution parameters and decompositions
    #
    
    mu.cond = mean.pred + Sigma.cross %*% 
      backsolve(Sigma.coord.chol, forwardsolve(t(Sigma.coord.chol), x - mean.x))
    
    Sigma.cond = forwardsolve(t(Sigma.coord.chol), t(Sigma.cross))
    Sigma.cond = Sigma.pred - t(Sigma.cond) %*% Sigma.cond
    
    Sigma.cond.chol = chol(Sigma.cond)
    
    # sample
    mu.cond + t(Sigma.cond.chol) %*% rnorm(nrow(d.pred))
    
  }
  
  
  #
  # compute distances
  #
  
  d = as.matrix(dist(rbind(coord.pred, fit$coord)))
  d.coord = d[(nrow(coord.pred)+1):nrow(d), (nrow(coord.pred)+1):nrow(d)]
  d.pred = d[1:nrow(coord.pred), 1:nrow(coord.pred)]
  d.cross = d[1:nrow(coord.pred), (nrow(coord.pred)+1):nrow(d)]
  
  #
  # Draw composition samples
  #
  
  p = 1 - 1/rl
  
  nsamp = nrow(fit$chain.loc)-burn+1
  
  krig.all = function() { 
    foreach(inds = ichunk(1:nsamp, chunkSize = ceiling(nsamp/ncores)),
            .combine = 'rbind', .export = c('fit', 'd.coord', 'd.pred', 'p',
                                            'd.cross', 'krig.samp', 'burn',
                                            'dsn.pred'),
            .packages = 'SpatialExtremes', .errorhandling='remove') %dorng% {
    foreach(inds = unlist(inds), .combine = 'rbind', 
            .errorhandling = 'remove') %do% {

      chain.loc = fit$chain.loc
      chain.scale = fit$chain.scale
      chain.scale[,-(1:5)] = log(chain.scale[,-(1:5)])
      chain.shape = fit$chain.shape

      tmp.loc = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      tmp.scale = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      tmp.shape = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))
      tmp.rl = matrix(NA, nrow = length(inds), ncol = nrow(d.pred))

      colnames(tmp.loc) = paste('loc', 1:nrow(d.pred), sep='')
      colnames(tmp.scale) = paste('scale', 1:nrow(d.pred), sep='')
      colnames(tmp.shape) = paste('shape', 1:nrow(d.pred), sep='')
      colnames(tmp.rl) = paste('rl', 1:nrow(d.pred), sep='')

      krig.single = function(chain, i, dsn.dat) {
        
        betas.ind = 1:2
        sill.ind = 3
        range.ind = 4
        smooth.ind = 5
        sample.ind = burn - 1 + i
        
        krig.samp(x = chain[sample.ind, 
                            -c(betas.ind, sill.ind, range.ind, smooth.ind)], 
                  d.coord = d.coord,
                  d.pred = d.pred, d.cross = d.cross, cov.mod = fit$cov.mod[1],
                  sill = chain[sample.ind, sill.ind], 
                  range = chain[sample.ind, range.ind],
                  smooth = chain[sample.ind, smooth.ind], 
                  mean.x = dsn.dat %*% chain[sample.ind,betas.ind], 
                  mean.pred = dsn.pred %*% chain[sample.ind,betas.ind])
      }

      for(j in 1:length(inds)) {
        i = inds[j]
        tmp.scale[j,] = exp(krig.single(chain.scale, i, fit$scale.dsgn.mat))
        tmp.loc[j,] = krig.single(chain.loc, i, fit$loc.dsgn.mat)
        tmp.shape[j,] = krig.single(chain.shape, i, fit$shape.dsgn.mat)
        tmp.rl[j,] = sapply(1:nrow(d.pred), function(i) {
          if(tmp.scale[j,i]>0) {
            qgev(p=p, loc = tmp.loc[j,i], scale = tmp.scale[j,i],
                 shape = tmp.shape[j,i])
          } else {
            NA
          }
        })
      }
    cbind(tmp.loc, tmp.scale, tmp.shape, tmp.rl)
    }
    }
  }
  
  krig = krig.all()
  
  locs.krig = krig[,1:nrow(d.pred)]
  scales.krig = krig[,(1:nrow(d.pred)) + nrow(d.pred)]
  shapes.krig = krig[,(1:nrow(d.pred)) + 2*nrow(d.pred)]
  rl.krig = krig[,(1:nrow(d.pred)) + 3*nrow(d.pred)]
  
  list(locs = locs.krig, scales = scales.krig, shapes = shapes.krig, 
       rl = rl.krig, coord = coord.pred)
}


fit.krig = composition.krig(fit, coord.pred, dsn.pred, burn = 1, 
                            ncores = ncores)
fit.wtd.krig = composition.krig(fit.wtd, coord.pred, dsn.pred, burn = 1, 
                                ncores = ncores)